bl_info = {
    "name": "barismsi Color Reveal",
    "author": "barismsi",
    "version": (4, 12, 2),
    "blender": (5, 1, 2),
    "location": "3D Viewport > N Panel > Renk Efekti",
    "description": "Kupleri renkli/renksiz alan, kameralari renkli/renksiz mod olarak ayarlar",
    "category": "Compositing",
}

import json
import threading

import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty
from bpy.types import Operator, Panel
from mathutils import Vector


EFFECT_NODE_NAME = "CR_ColorReveal_Effect"
PASS_NODE_NAME = "CR_ColorReveal_Passes"
GROUP_PREFIX = "CR_ColorReveal_Group_"
GROUP_API_VERSION = 19
MAX_CONTROLLERS = 32
CONTROLLER_MARKER = "cr_color_reveal_controller"
CONTROLLER_MODE = "cr_color_reveal_mode"
CAMERA_MODE = "cr_color_reveal_camera_mode"

SELECTED_AOV_NAME = "CR_Selected_Color_Mask"
SELECTED_PASS_INDEX = 731
SELECTED_MARKER = "cr_keep_selected_color"
SELECTED_PREVIOUS_PASS = "_cr_selected_previous_pass_index"
SELECTED_GROUP_MARKER = "_cr_selected_color_group"
MAX_SELECTED_GROUPS = 64
CRYPTOMATTE_NODE_PREFIX = "CR_Selected_Cryptomatte_"
SELECTED_MATERIAL_BACKUP = "_cr_selected_material_backup"
SELECTED_MATERIAL_COPY_MARKER = "cr_selected_mask_copy"
SELECTED_MATERIAL_NODES = (
    "CR_Selected_Object_Info",
    "CR_Selected_Index_Match",
    "CR_Selected_AOV_Output",
)

LEGACY_AOV_NAME = "CR_Character_Mask"
LEGACY_MATERIAL_NODES = (
    "CR_Character_Object_Info",
    "CR_Character_Index_Match",
    "CR_Character_AOV_Output",
)

_SYNCING = False
_PREPARING = False
_RENDERING = False
_REGISTERED = False
_FRAME_DIRTY = True
_PREVIEW_RENDER_STATE = None
_PREVIEW_RESTORE_PENDING = False


def _render_in_progress():
    return _RENDERING or bpy.app.is_job_running("RENDER")


def _assert_setup_is_safe(scene=None):
    # Render handlers can receive evaluated IDs and run on the render worker.
    # Neither may be used to rebuild nodes, drivers, materials or object IDs.
    if threading.current_thread() is not threading.main_thread():
        raise RuntimeError("Efekt kurulumu yalniz ana Blender is parcaciginda yapilabilir.")
    if _render_in_progress():
        raise RuntimeError("Render surerken efekt kurulumu yapilamaz; once renderi bitirin.")
    if scene is not None and scene.is_evaluated:
        raise RuntimeError("Degerlendirilmis sahneye yazilamaz; asil sahneyi kullanin.")


def _new_group_socket(group, name, in_out, socket_type):
    return group.interface.new_socket(
        name=name,
        in_out=in_out,
        socket_type=socket_type,
    )


def _socket_by_identifier(sockets, identifier):
    return next(
        (socket for socket in sockets if socket.identifier == identifier),
        None,
    )


def _set_vector_socket(socket, *components):
    values = list(socket.default_value)
    changed = any(
        abs(float(values[index]) - float(component)) > 0.000001
        for index, component in enumerate(components)
    )
    if not changed:
        return False
    for index, component in enumerate(components):
        values[index] = component
    socket.default_value = values
    return True


def _set_scalar_socket(socket, value):
    if abs(float(socket.default_value) - float(value)) <= 0.000001:
        return False
    socket.default_value = value
    return True


def _tag_compositor_update(scene, group=None):
    if group is not None:
        group.update_tag()
    tree = scene.compositing_node_group
    if tree is not None:
        tree.update_tag()

    if _render_in_progress() or threading.current_thread() is not threading.main_thread():
        return
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _cycles_object_preview_required(scene):
    return bool(
        (_colored_objects(scene) or _controllers(scene))
        and scene.render.engine == "CYCLES"
    )


def _preview_space_is_ready(space, scene):
    if space is None or space.type != "VIEW_3D":
        return False
    region_3d = getattr(space, "region_3d", None)
    shading = getattr(space, "shading", None)
    shading_ready = bool(
        shading
        and (
            shading.type == "MATERIAL"
            if _cycles_object_preview_required(scene)
            else shading.type in {"MATERIAL", "RENDERED"}
        )
    )
    return bool(
        region_3d
        and shading_ready
        and region_3d.view_perspective == "CAMERA"
        and shading.use_compositor in {"CAMERA", "ALWAYS"}
    )


def _configure_preview_space(space, scene):
    if space is None or space.type != "VIEW_3D":
        return False

    # Blender 5.1'de Cycles Viewport Compositor, Image/Alpha/Depth disindaki
    # render pass'lerini bos birakir. Secili nesne maskesi bir Shader AOV
    # oldugu icin canli nesne onizlemesini EEVEE tabanli Material Preview ile
    # gosteriyoruz. Sahnenin final render motoru (ornegin Cycles) degismez.
    use_material_preview = _cycles_object_preview_required(scene)
    space.shading.type = "MATERIAL" if use_material_preview else "RENDERED"
    space.shading.use_compositor = "CAMERA"
    space.overlay.show_overlays = True
    if space.region_3d is not None:
        space.region_3d.view_perspective = "CAMERA"
    return True


def _enable_live_preview(context):
    scene = context.scene
    if scene.camera is None:
        return 0

    scene.render.use_compositing = True

    areas = []
    if context.area is not None and context.area.type == "VIEW_3D":
        areas.append(context.area)
    elif context.screen is not None:
        areas.extend(area for area in context.screen.areas if area.type == "VIEW_3D")

    configured = 0
    for area in areas[:1]:
        space = area.spaces.active
        if _configure_preview_space(space, scene):
            configured += 1
            area.tag_redraw()
    return configured


def _volume_node_name(index, suffix):
    return f"CR_Volume_{suffix}" if index == 0 else f"CR_Volume_{index:02d}_{suffix}"


def _controller_mode(controller):
    return "GRAY" if controller.get(CONTROLLER_MODE, "COLOR") == "GRAY" else "COLOR"


def _controller_signature(scene):
    return "|".join(
        f"{controller.name_full}:{_controller_mode(controller)}"
        for controller in _controllers(scene)
    )


def _camera_mode(camera):
    if camera is None:
        return "NORMAL"
    mode = str(camera.get(CAMERA_MODE, "NORMAL"))
    return mode if mode in {"NORMAL", "COLOR", "GRAY"} else "NORMAL"


def _active_camera_for_frame(scene):
    """Return the camera Blender's timeline camera markers select this frame.

    frame_change_post may run just before scene.camera reflects a camera marker.
    Resolving the marker here prevents the previous camera mode lasting one frame.
    """
    camera_markers = [
        marker for marker in scene.timeline_markers
        if getattr(marker, "camera", None) is not None
    ]
    if not camera_markers:
        return scene.camera
    current_or_earlier = [
        marker for marker in camera_markers
        if marker.frame <= scene.frame_current
    ]
    if current_or_earlier:
        marker = max(current_or_earlier, key=lambda item: item.frame)
    else:
        marker = min(camera_markers, key=lambda item: item.frame)
    return marker.camera


def _build_volume_mask_nodes(nodes, links, group_in, index):
    """Create one camera-independent oriented box mask and return its output."""
    base_y = -100 - index * 440

    volume_offset = nodes.new("ShaderNodeVectorMath")
    volume_offset.name = _volume_node_name(index, "Offset")
    volume_offset.label = f"Dunya Konumu - Kup {index + 1} Merkezi"
    volume_offset.operation = "SUBTRACT"
    volume_offset.location = (-700, base_y)
    _set_vector_socket(volume_offset.inputs[1], 1000000.0, 1000000.0, 1000000.0)

    normalized_axes = []
    for axis_index, axis_name in enumerate("XYZ"):
        y = base_y - axis_index * 105
        dot = nodes.new("ShaderNodeVectorMath")
        dot.name = _volume_node_name(index, f"Dot_{axis_name}")
        dot.label = f"Kup {index + 1} {axis_name} Ekseni"
        dot.operation = "DOT_PRODUCT"
        dot.location = (-500, y)
        axis = (
            1.0 if axis_index == 0 else 0.0,
            1.0 if axis_index == 1 else 0.0,
            1.0 if axis_index == 2 else 0.0,
        )
        _set_vector_socket(dot.inputs[1], *axis)

        absolute = nodes.new("ShaderNodeMath")
        absolute.name = _volume_node_name(index, f"Abs_{axis_name}")
        absolute.operation = "ABSOLUTE"
        absolute.location = (-320, y)

        normalize = nodes.new("ShaderNodeMath")
        normalize.name = _volume_node_name(index, f"Normalize_{axis_name}")
        normalize.operation = "DIVIDE"
        normalize.location = (-150, y)
        normalize.inputs[1].default_value = 0.0001

        links.new(volume_offset.outputs[0], dot.inputs[0])
        links.new(dot.outputs[1], absolute.inputs[0])
        links.new(absolute.outputs[0], normalize.inputs[0])
        normalized_axes.append(normalize.outputs[0])

    max_xy = nodes.new("ShaderNodeMath")
    max_xy.name = _volume_node_name(index, "Max_XY")
    max_xy.operation = "MAXIMUM"
    max_xy.location = (20, base_y - 30)
    links.new(normalized_axes[0], max_xy.inputs[0])
    links.new(normalized_axes[1], max_xy.inputs[1])

    max_xyz = nodes.new("ShaderNodeMath")
    max_xyz.name = _volume_node_name(index, "Max_XYZ")
    max_xyz.label = f"Kup {index + 1} Icinde Uzaklik"
    max_xyz.operation = "MAXIMUM"
    max_xyz.location = (180, base_y - 30)
    links.new(max_xy.outputs[0], max_xyz.inputs[0])
    links.new(normalized_axes[2], max_xyz.inputs[1])

    falloff_normalize = nodes.new("ShaderNodeMath")
    falloff_normalize.name = _volume_node_name(index, "Falloff_Normalize")
    falloff_normalize.label = f"Kup {index + 1} Kenari Yumusakligi"
    falloff_normalize.operation = "MULTIPLY_ADD"
    falloff_normalize.use_clamp = True
    falloff_normalize.location = (340, base_y - 30)

    falloff_squared = nodes.new("ShaderNodeMath")
    falloff_squared.name = _volume_node_name(index, "Falloff_Squared")
    falloff_squared.operation = "MULTIPLY"
    falloff_squared.location = (500, base_y - 10)

    falloff_curve = nodes.new("ShaderNodeMath")
    falloff_curve.name = _volume_node_name(index, "Falloff_Curve")
    falloff_curve.operation = "MULTIPLY_ADD"
    falloff_curve.location = (500, base_y - 90)
    falloff_curve.inputs[1].default_value = -2.0
    falloff_curve.inputs[2].default_value = 3.0

    falloff_smooth = nodes.new("ShaderNodeMath")
    falloff_smooth.name = _volume_node_name(index, "Falloff_Smooth")
    falloff_smooth.operation = "MULTIPLY"
    falloff_smooth.location = (660, base_y - 30)

    volume_mask = nodes.new("ShaderNodeMath")
    volume_mask.name = _volume_node_name(index, "Mask")
    volume_mask.label = f"Dunyada Sabit Kup Hacmi {index + 1}"
    volume_mask.operation = "SUBTRACT"
    volume_mask.location = (820, base_y - 30)
    volume_mask.inputs[0].default_value = 1.0

    links.new(group_in.outputs["Position"], volume_offset.inputs[0])
    links.new(max_xyz.outputs[0], falloff_normalize.inputs[0])
    links.new(falloff_normalize.outputs[0], falloff_squared.inputs[0])
    links.new(falloff_normalize.outputs[0], falloff_squared.inputs[1])
    links.new(falloff_normalize.outputs[0], falloff_curve.inputs[0])
    links.new(falloff_squared.outputs[0], falloff_smooth.inputs[0])
    links.new(falloff_curve.outputs[0], falloff_smooth.inputs[1])
    links.new(falloff_smooth.outputs[0], volume_mask.inputs[1])
    return volume_mask.outputs[0]


def _build_group(scene):
    group = bpy.data.node_groups.new(
        name=f"{GROUP_PREFIX}{scene.name}",
        type="CompositorNodeTree",
    )
    scene["cr_group_name"] = group.name
    group["cr_api_version"] = GROUP_API_VERSION
    controllers = _controllers(scene)
    if len(controllers) > MAX_CONTROLLERS:
        raise RuntimeError(f"En fazla {MAX_CONTROLLERS} kontrol kupu kullanilabilir.")
    group["cr_controller_count"] = len(controllers)
    group["cr_controller_signature"] = _controller_signature(scene)

    _new_group_socket(group, "Image", "INPUT", "NodeSocketColor")
    _new_group_socket(group, "Position", "INPUT", "NodeSocketVector")
    _new_group_socket(group, "Object Mask", "INPUT", "NodeSocketFloat")
    _new_group_socket(group, "Object Index", "INPUT", "NodeSocketFloat")
    for index in range(MAX_SELECTED_GROUPS):
        _new_group_socket(
            group,
            f"Crypto Mask {index:02d}",
            "INPUT",
            "NodeSocketFloat",
        )
    _new_group_socket(group, "Image", "OUTPUT", "NodeSocketColor")

    nodes = group.nodes
    links = group.links

    group_in = nodes.new("NodeGroupInput")
    group_in.name = "CR_Group_Input"
    group_in.location = (-760, 80)

    group_out = nodes.new("NodeGroupOutput")
    group_out.name = "CR_Group_Output"
    group_out.location = (980, 80)

    grayscale = nodes.new("CompositorNodeHueSat")
    grayscale.name = "CR_Grayscale"
    grayscale.label = "Dis Alani Siyah-Beyaz Yap"
    grayscale.location = (-500, 220)
    grayscale.inputs["Saturation"].default_value = scene.cr_outside_saturation

    yellow_filter = nodes.new("CompositorNodeColorBalance")
    yellow_filter.name = "CR_Yellow_Filter"
    yellow_filter.label = "Ayarlanabilir Sari Filtre"
    yellow_filter.location = (560, 80)
    yellow_factor = _socket_by_identifier(yellow_filter.inputs, "Fac")
    yellow_image = _socket_by_identifier(yellow_filter.inputs, "Image")
    yellow_gamma = _socket_by_identifier(yellow_filter.inputs, "Color Gamma")
    yellow_gain = _socket_by_identifier(yellow_filter.inputs, "Color Gain")
    yellow_result = _socket_by_identifier(yellow_filter.outputs, "Image")
    if not all(
        (yellow_factor, yellow_image, yellow_gamma, yellow_gain, yellow_result)
    ):
        raise RuntimeError("Blender 5.1 sari filtre soketleri bulunamadi.")
    yellow_factor.default_value = scene.cr_yellow_filter
    yellow_gamma.default_value = (1.0, 0.96, 0.80, 1.0)
    yellow_gain.default_value = (1.08, 1.0, 0.72, 1.0)

    purple_filter = nodes.new("CompositorNodeColorBalance")
    purple_filter.name = "CR_Purple_Filter"
    purple_filter.label = "Ayarlanabilir Mor Filtre"
    purple_filter.location = (760, 80)
    purple_factor = _socket_by_identifier(purple_filter.inputs, "Fac")
    purple_image = _socket_by_identifier(purple_filter.inputs, "Image")
    purple_gamma = _socket_by_identifier(purple_filter.inputs, "Color Gamma")
    purple_gain = _socket_by_identifier(purple_filter.inputs, "Color Gain")
    purple_result = _socket_by_identifier(purple_filter.outputs, "Image")
    if not all(
        (purple_factor, purple_image, purple_gamma, purple_gain, purple_result)
    ):
        raise RuntimeError("Blender 5.1 mor filtre soketleri bulunamadi.")
    purple_factor.default_value = scene.cr_purple_filter
    purple_gamma.default_value = (1.0, 0.84, 1.0, 1.0)
    purple_gain.default_value = (1.08, 0.70, 1.12, 1.0)

    # Her kontrol objesi dunya uzayinda ayri bir hacim uretir. Hacimler MAXIMUM
    # ile birlestirilir; kamera konumu veya aktif kamera bu hesaba girmez.
    volume_sources = {"COLOR": None, "GRAY": None}
    volume_counts = {"COLOR": 0, "GRAY": 0}
    for index, controller in enumerate(controllers):
        current_source = _build_volume_mask_nodes(nodes, links, group_in, index)
        mode = _controller_mode(controller)
        volume_counts[mode] += 1
        previous_source = volume_sources[mode]
        if previous_source is None:
            volume_sources[mode] = current_source
        else:
            union = nodes.new("ShaderNodeMath")
            union.name = f"CR_{mode.title()}_Volume_Union_{index:02d}"
            union.label = f"{mode.title()} Kup Hacimleri: {volume_counts[mode]}"
            union.operation = "MAXIMUM"
            union.location = (980, -100 - index * 80)
            links.new(previous_source, union.inputs[0])
            links.new(current_source, union.inputs[1])
            volume_sources[mode] = union.outputs[0]

    for mode in ("COLOR", "GRAY"):
        if volume_sources[mode] is not None:
            continue
        empty_volume = nodes.new("ShaderNodeMath")
        empty_volume.name = f"CR_Empty_{mode.title()}_Volume"
        empty_volume.operation = "MULTIPLY"
        empty_volume.inputs[0].default_value = 0.0
        empty_volume.inputs[1].default_value = 0.0
        volume_sources[mode] = empty_volume.outputs[0]

    position_length = nodes.new("ShaderNodeVectorMath")
    position_length.name = "CR_Position_Length"
    position_length.operation = "LENGTH"
    position_length.location = (340, -260)

    position_valid = nodes.new("ShaderNodeMath")
    position_valid.name = "CR_Position_Valid"
    position_valid.label = "Arka Plani Hacimden Cikar"
    position_valid.operation = "GREATER_THAN"
    position_valid.location = (500, -260)
    position_valid.inputs[1].default_value = 0.000001

    volume_surface_mask = nodes.new("ShaderNodeMath")
    volume_surface_mask.name = "CR_Volume_Surface_Mask"
    volume_surface_mask.operation = "MULTIPLY"
    volume_surface_mask.location = (980, -130)

    gray_volume_surface_mask = nodes.new("ShaderNodeMath")
    gray_volume_surface_mask.name = "CR_Gray_Volume_Surface_Mask"
    gray_volume_surface_mask.label = "Renksiz Kup Hacimleri"
    gray_volume_surface_mask.operation = "MULTIPLY"
    gray_volume_surface_mask.location = (980, -230)

    links.new(group_in.outputs["Position"], position_length.inputs[0])
    links.new(position_length.outputs[1], position_valid.inputs[0])
    links.new(volume_sources["COLOR"], volume_surface_mask.inputs[0])
    links.new(position_valid.outputs[0], volume_surface_mask.inputs[1])
    links.new(volume_sources["GRAY"], gray_volume_surface_mask.inputs[0])
    links.new(position_valid.outputs[0], gray_volume_surface_mask.inputs[1])

    # EEVEE/Material Preview icin Shader AOV kullanilir. Cycles final renderda
    # Object Index ve isim tabanli Cryptomatte tam nesne siluetini hedefler.
    index_mask_source = None
    for index in range(MAX_SELECTED_GROUPS):
        id_mask = nodes.new("CompositorNodeIDMask")
        id_mask.name = f"CR_Selected_ID_Mask_{index:02d}"
        id_mask.label = f"Cycles Nesne Grubu {index + 1}"
        id_mask.location = (-610, -420 - index * 90)
        id_mask.inputs["Index"].default_value = SELECTED_PASS_INDEX + index
        id_mask.inputs["Anti-Alias"].default_value = True

        group_mask = nodes.new("ShaderNodeMath")
        group_mask.name = f"CR_Selected_Group_Mask_{index:02d}"
        group_mask.label = f"Object Index + Cryptomatte {index + 1}"
        group_mask.operation = "MAXIMUM"
        group_mask.location = (-390, -420 - index * 90)
        group_mask.inputs[0].default_value = 0.0
        group_mask.inputs[1].default_value = 0.0

        index_amount = nodes.new("ShaderNodeMath")
        index_amount.name = f"CR_Selected_ID_Amount_{index:02d}"
        index_amount.operation = "MULTIPLY"
        index_amount.location = (-170, -420 - index * 90)
        index_amount.inputs[1].default_value = 0.0

        links.new(group_in.outputs["Object Index"], id_mask.inputs["ID value"])
        links.new(id_mask.outputs["Alpha"], group_mask.inputs[0])
        links.new(group_in.outputs[f"Crypto Mask {index:02d}"], group_mask.inputs[1])
        links.new(group_mask.outputs[0], index_amount.inputs[0])

        if index_mask_source is None:
            index_mask_source = index_amount.outputs[0]
        else:
            union = nodes.new("ShaderNodeMath")
            union.name = f"CR_Selected_ID_Union_{index:02d}"
            union.operation = "MAXIMUM"
            union.location = (30, -420 - index * 90)
            links.new(index_mask_source, union.inputs[0])
            links.new(index_amount.outputs[0], union.inputs[1])
            index_mask_source = union.outputs[0]

    selected_mask_union = nodes.new("ShaderNodeMath")
    selected_mask_union.name = "CR_Selected_Exact_Mask"
    selected_mask_union.label = "AOV + Object Index + Cryptomatte"
    selected_mask_union.operation = "MAXIMUM"
    selected_mask_union.location = (-120, -350)
    links.new(group_in.outputs["Object Mask"], selected_mask_union.inputs[0])
    links.new(index_mask_source, selected_mask_union.inputs[1])
    selected_mask_source = selected_mask_union.outputs[0]

    area_strength = nodes.new("ShaderNodeMath")
    area_strength.name = "CR_Area_Mode_Strength"
    area_strength.operation = "MULTIPLY"
    area_strength.location = (-140, -100)

    cube_amount = nodes.new("ShaderNodeMath")
    cube_amount.name = "CR_Cube_Color_Amount"
    cube_amount.label = "Animasyonlu Kup Renk Miktari"
    cube_amount.operation = "MULTIPLY"
    cube_amount.location = (-330, -190)
    cube_amount.inputs[0].default_value = scene.cr_cube_color_amount
    cube_amount.inputs[1].default_value = 1.0

    object_strength = nodes.new("ShaderNodeMath")
    object_strength.name = "CR_Object_Mode_Strength"
    object_strength.operation = "MULTIPLY"
    object_strength.location = (-140, -300)
    object_strength.inputs[1].default_value = (
        1.0
    )

    combine_masks = nodes.new("ShaderNodeMath")
    combine_masks.name = "CR_Combine_Masks"
    combine_masks.label = "Renkli Kup Hacimleri"
    combine_masks.operation = "MAXIMUM"
    combine_masks.location = (70, -170)
    combine_masks.inputs[1].default_value = 0.0

    full_scene_mask = nodes.new("ShaderNodeMath")
    full_scene_mask.name = "CR_Full_Scene_Mask"
    full_scene_mask.label = "Tum Goruntuyu Renkli Yap"
    full_scene_mask.operation = "MAXIMUM"
    full_scene_mask.location = (190, -170)
    full_scene_mask.inputs[1].default_value = scene.cr_full_scene_color_amount

    camera_color = nodes.new("ShaderNodeMath")
    camera_color.name = "CR_Camera_Color_Mode"
    camera_color.label = "Aktif Kamera Tam Renkli"
    camera_color.operation = "MULTIPLY"
    camera_color.location = (300, -190)
    camera_color.inputs[0].default_value = 0.0
    camera_color.inputs[1].default_value = 1.0

    positive_with_camera = nodes.new("ShaderNodeMath")
    positive_with_camera.name = "CR_Positive_With_Camera"
    positive_with_camera.label = "Alanlar + Renkli Kamera"
    positive_with_camera.operation = "MAXIMUM"
    positive_with_camera.location = (410, -170)

    gray_area_strength = nodes.new("ShaderNodeMath")
    gray_area_strength.name = "CR_Gray_Area_Strength"
    gray_area_strength.label = "Renksiz Kup Etkisi"
    gray_area_strength.operation = "MULTIPLY"
    gray_area_strength.location = (190, -300)

    gray_area_invert = nodes.new("ShaderNodeMath")
    gray_area_invert.name = "CR_Gray_Area_Invert"
    gray_area_invert.operation = "SUBTRACT"
    gray_area_invert.location = (410, -300)
    gray_area_invert.inputs[0].default_value = 1.0

    after_gray_cubes = nodes.new("ShaderNodeMath")
    after_gray_cubes.name = "CR_After_Gray_Cubes"
    after_gray_cubes.label = "Renksiz Kupler Oncelikli"
    after_gray_cubes.operation = "MULTIPLY"
    after_gray_cubes.location = (560, -170)

    camera_gray = nodes.new("ShaderNodeMath")
    camera_gray.name = "CR_Camera_Gray_Mode"
    camera_gray.label = "Aktif Kamera Taban Renksiz"
    camera_gray.operation = "MULTIPLY"
    camera_gray.location = (500, -390)
    camera_gray.inputs[0].default_value = 0.0
    camera_gray.inputs[1].default_value = 1.0

    selected_override = nodes.new("ShaderNodeMath")
    selected_override.name = "CR_Selected_Final_Override"
    selected_override.label = "Secilen Nesneler En Ustte Renkli"
    selected_override.operation = "MAXIMUM"
    selected_override.location = (920, -170)

    mix = nodes.new("ShaderNodeMix")
    mix.name = "CR_Final_Mix"
    mix.label = "Renkli / Siyah-Beyaz"
    mix.data_type = "RGBA"
    mix.blend_type = "MIX"
    mix.clamp_factor = True
    mix.location = (300, 80)

    mix_factor = _socket_by_identifier(mix.inputs, "Factor_Float")
    mix_gray = _socket_by_identifier(mix.inputs, "A_Color")
    mix_color = _socket_by_identifier(mix.inputs, "B_Color")
    mix_result = _socket_by_identifier(mix.outputs, "Result_Color")
    if not all((mix_factor, mix_gray, mix_color, mix_result)):
        raise RuntimeError("Blender 5.1 Mix dugumu soketleri bulunamadi.")

    links.new(group_in.outputs["Image"], grayscale.inputs["Image"])
    links.new(volume_surface_mask.outputs[0], area_strength.inputs[0])
    links.new(cube_amount.outputs[0], area_strength.inputs[1])
    links.new(selected_mask_source, object_strength.inputs[0])
    links.new(area_strength.outputs[0], combine_masks.inputs[0])
    links.new(combine_masks.outputs[0], full_scene_mask.inputs[0])
    links.new(full_scene_mask.outputs[0], positive_with_camera.inputs[0])
    links.new(camera_color.outputs[0], positive_with_camera.inputs[1])
    links.new(gray_volume_surface_mask.outputs[0], gray_area_strength.inputs[0])
    links.new(cube_amount.outputs[0], gray_area_strength.inputs[1])
    links.new(gray_area_strength.outputs[0], gray_area_invert.inputs[1])
    links.new(positive_with_camera.outputs[0], after_gray_cubes.inputs[0])
    links.new(gray_area_invert.outputs[0], after_gray_cubes.inputs[1])
    # Renksiz kamera yalniz taban goruntuyu gri yapar. Renkli kupler ve renkli
    # tutulan nesneler bu tabanin uzerinde renk gostermeye devam eder.
    links.new(after_gray_cubes.outputs[0], selected_override.inputs[0])
    links.new(object_strength.outputs[0], selected_override.inputs[1])
    links.new(selected_override.outputs[0], mix_factor)
    links.new(grayscale.outputs["Image"], mix_gray)
    links.new(group_in.outputs["Image"], mix_color)
    links.new(mix_result, yellow_image)
    links.new(yellow_result, purple_image)
    links.new(purple_result, group_out.inputs["Image"])

    return group


def _get_group(scene):
    name = scene.get("cr_group_name", "")
    group = bpy.data.node_groups.get(name) if name else None
    if (
        group
        and group.get("cr_api_version") == GROUP_API_VERSION
        and int(group.get("cr_controller_count", -1)) == len(_controllers(scene))
        and group.get("cr_controller_signature", "") == _controller_signature(scene)
        and group.nodes.get("CR_Volume_Surface_Mask")
    ):
        return group

    _assert_setup_is_safe(scene)
    if group and group.name.startswith(GROUP_PREFIX):
        bpy.data.node_groups.remove(group, do_unlink=True)
    return _build_group(scene)


def _get_scene_compositor_tree(scene):
    tree = scene.compositing_node_group
    if tree is None:
        tree = bpy.data.node_groups.new(
            name=f"CR_Compositor_{scene.name}",
            type="CompositorNodeTree",
        )
        scene.compositing_node_group = tree
    return tree


def _ensure_main_output_socket(tree):
    for item in tree.interface.items_tree:
        if (
            getattr(item, "item_type", "") == "SOCKET"
            and getattr(item, "in_out", "") == "OUTPUT"
            and item.name == "Image"
        ):
            return item
    return tree.interface.new_socket(
        name="Image",
        in_out="OUTPUT",
        socket_type="NodeSocketColor",
    )


def _ensure_selected_aov(scene, view_layer_name):
    view_layer = scene.view_layers.get(view_layer_name)
    if view_layer is None:
        view_layer = scene.view_layers[0]

    # Kullanici aktif View Layer'i sonradan degistirse bile Cycles maskesi
    # kaybolmasin diye gerekli gecisleri sahnedeki tum katmanlarda ac.
    for layer in scene.view_layers:
        if hasattr(layer, "use_pass_position"):
            layer.use_pass_position = True
        if hasattr(layer, "use_pass_object_index"):
            layer.use_pass_object_index = True
        if hasattr(layer, "use_pass_cryptomatte_object"):
            layer.use_pass_cryptomatte_object = True
        if hasattr(layer, "pass_cryptomatte_depth"):
            layer.pass_cryptomatte_depth = max(6, layer.pass_cryptomatte_depth)
        if hasattr(layer, "use_pass_cryptomatte_accurate"):
            layer.use_pass_cryptomatte_accurate = True
        aov = layer.aovs.get(SELECTED_AOV_NAME)
        if aov is None:
            aov = layer.aovs.add()
            aov.name = SELECTED_AOV_NAME
        aov.type = "VALUE"
    return view_layer


def _object_index_output(node):
    """Blender 5.1 renamed the compositor socket from IndexOB to Object Index."""
    return node.outputs.get("Object Index") or node.outputs.get("IndexOB")


def _find_or_create_render_layers_node(tree, scene, view_layer_name):
    node = tree.nodes.get(PASS_NODE_NAME)
    if node and node.bl_idname != "CompositorNodeRLayers":
        tree.nodes.remove(node)
        node = None

    if node is None:
        node = tree.nodes.new("CompositorNodeRLayers")
        node.name = PASS_NODE_NAME
        node.label = "Renk Efekti - Goruntu"
        node.location = (-430, 20)

    if hasattr(node, "scene"):
        node.scene = scene
    try:
        node.layer = view_layer_name
    except (AttributeError, TypeError):
        pass

    if (
        node.outputs.get(SELECTED_AOV_NAME) is None
        or node.outputs.get("Position") is None
        or (scene.render.engine == "CYCLES" and _object_index_output(node) is None)
    ):
        outgoing = [(link.from_socket.name, link.to_socket) for link in tree.links
                    if link.from_node == node]
        tree.nodes.remove(node)
        node = tree.nodes.new("CompositorNodeRLayers")
        node.name = PASS_NODE_NAME
        node.label = "Renk Efekti - Goruntu ve Nesne Maskesi"
        node.location = (-430, 20)
        if hasattr(node, "scene"):
            node.scene = scene
        try:
            node.layer = view_layer_name
        except (AttributeError, TypeError):
            pass
        for socket_name, target in outgoing:
            source = node.outputs.get(socket_name)
            if source is not None:
                tree.links.new(source, target)
    return node


def _find_or_create_group_output(tree):
    outputs = [node for node in tree.nodes if node.bl_idname == "NodeGroupOutput"]
    if outputs:
        node = next((node for node in outputs if node.is_active_output), outputs[0])
        try:
            node.is_active_output = True
        except (AttributeError, TypeError):
            pass
        return node

    node = tree.nodes.new("NodeGroupOutput")
    node.name = "CR_Compositor_Output"
    node.location = (620, 80)
    try:
        node.is_active_output = True
    except (AttributeError, TypeError):
        pass
    return node


def _find_saved_source(tree, effect):
    source_node = tree.nodes.get(effect.get("cr_source_node", ""))
    if source_node is None:
        return None
    return source_node.outputs.get(effect.get("cr_source_socket", "Image"))


def _ensure_effect(scene, view_layer_name):
    _assert_setup_is_safe(scene)
    scene.render.use_compositing = True
    # Animated cube masks update existing compositor values while rendering.
    # Lock the viewport before the job starts, as required by Blender handlers.
    scene.render.use_lock_interface = True
    tree = _get_scene_compositor_tree(scene)
    _ensure_main_output_socket(tree)
    _ensure_selected_aov(scene, view_layer_name)
    group = _get_group(scene)
    _ensure_controller_dependency(scene, group)
    pass_node = _find_or_create_render_layers_node(tree, scene, view_layer_name)
    output = _find_or_create_group_output(tree)
    output_image = output.inputs.get("Image")
    if output_image is None:
        raise RuntimeError("Ana compositor Image cikisi olusturulamadi.")

    effect = tree.nodes.get(EFFECT_NODE_NAME)
    if effect and effect.bl_idname != "CompositorNodeGroup":
        tree.nodes.remove(effect)
        effect = None

    output_source = (
        output_image.links[0].from_socket
        if output_image.is_linked
        else None
    )

    if effect is None:
        effect = tree.nodes.new("CompositorNodeGroup")
        effect.name = EFFECT_NODE_NAME
        effect.label = "barismsi - Obje Arkasi Renkli"
        effect.location = (output.location.x - 280, output.location.y)

    old_effect_source = None
    old_image_input = effect.inputs.get("Image")
    if old_image_input and old_image_input.is_linked:
        old_effect_source = old_image_input.links[0].from_socket

    effect.node_tree = group

    image_input = effect.inputs.get("Image")
    if image_input is None:
        raise RuntimeError("Efekt grubunda Image girisi bulunamadi.")

    if not image_input.is_linked:
        source_socket = old_effect_source
        if source_socket is None and output_source and output_source.node != effect:
            source_socket = output_source
        if source_socket is None:
            source_socket = _find_saved_source(tree, effect)
        if source_socket is None:
            source_socket = pass_node.outputs.get("Image")
        if source_socket is None:
            raise RuntimeError("Render Layers Image cikisi bulunamadi.")

        tree.links.new(source_socket, image_input)
        effect["cr_source_node"] = source_socket.node.name
        effect["cr_source_socket"] = source_socket.name

    object_mask_input = effect.inputs.get("Object Mask")
    object_mask_output = pass_node.outputs.get(SELECTED_AOV_NAME)
    if object_mask_input is None or object_mask_output is None:
        raise RuntimeError("Secilen nesne maskesi compositor baglantisi olusturulamadi.")
    if object_mask_input.is_linked:
        for link in list(object_mask_input.links):
            if link.from_socket != object_mask_output:
                tree.links.remove(link)
    if not object_mask_input.is_linked:
        tree.links.new(object_mask_output, object_mask_input)

    position_input = effect.inputs.get("Position")
    position_output = pass_node.outputs.get("Position")
    if position_input is None or position_output is None:
        raise RuntimeError("Dunyada sabit kup icin Position render gecidi bulunamadi.")
    if position_input.is_linked:
        for link in list(position_input.links):
            if link.from_socket != position_output:
                tree.links.remove(link)
    if not position_input.is_linked:
        tree.links.new(position_output, position_input)

    object_index_input = effect.inputs.get("Object Index")
    object_index_output = _object_index_output(pass_node)
    if object_index_input is None:
        raise RuntimeError("Cycles Object Index maskesi olusturulamadi.")
    if object_index_output is not None:
        if object_index_input.is_linked:
            for link in list(object_index_input.links):
                if link.from_socket != object_index_output:
                    tree.links.remove(link)
        if not object_index_input.is_linked:
            tree.links.new(object_index_output, object_index_input)

    _sync_selected_render_masks(
        scene,
        group=group,
        tree=tree,
        effect=effect,
        view_layer_name=view_layer_name,
    )

    if output_image.is_linked:
        for link in list(output_image.links):
            if link.from_node != effect:
                tree.links.remove(link)
    if not output_image.is_linked:
        tree.links.new(effect.outputs["Image"], output_image)

    return effect


def _controller_dependency_ready(scene, group):
    controllers = _controllers(scene)
    if not controllers:
        return True
    if group is None or not group.animation_data:
        return False
    for index, controller in enumerate(controllers):
        name = "CR_Controller_Dependency" if index == 0 else f"CR_Controller_Dependency_{index:02d}"
        node = group.nodes.get(name)
        if node is None:
            return False
        path = node.inputs[0].path_from_id("default_value")
        fcurve = group.animation_data.drivers.find(path)
        if not (
            fcurve
            and any(
                variable.type == "TRANSFORMS"
                and variable.targets[0].id == controller
                for variable in fcurve.driver.variables
            )
        ):
            return False
    return True


def _ensure_controller_dependency(scene, group):
    """Keep a hidden controller's animation evaluated by the render depsgraph.

    A native transform driver establishes the dependency. x * 0 + 1 leaves the
    area strength unchanged; no Python expression or visible proxy is needed.
    """
    _assert_setup_is_safe(scene)
    controllers = _controllers(scene)
    if not controllers or _controller_dependency_ready(scene, group):
        return
    cube_amount = group.nodes.get("CR_Cube_Color_Amount")
    if cube_amount is None:
        raise RuntimeError("Kup renk miktari dugumu bulunamadi.")

    for old_node in list(group.nodes):
        if old_node.name.startswith("CR_Controller_Dependency_Union_"):
            group.nodes.remove(old_node)

    dependency_source = None
    for index, controller in enumerate(controllers):
        name = "CR_Controller_Dependency" if index == 0 else f"CR_Controller_Dependency_{index:02d}"
        node = group.nodes.get(name)
        if node is None:
            node = group.nodes.new("ShaderNodeMath")
            node.name = name
        node.label = f"Gizli Kup {index + 1} Animasyon Bagimliligi"
        node.location = (-520, -210 - index * 70)
        node.operation = "MULTIPLY_ADD"
        node.inputs[1].default_value = 0.0
        node.inputs[2].default_value = 1.0
        node.inputs[0].driver_remove("default_value")
        driver = node.inputs[0].driver_add("default_value").driver
        driver.type = "AVERAGE"
        for old_variable in list(driver.variables):
            driver.variables.remove(old_variable)
        variable = driver.variables.new()
        variable.name = f"kontrol_{index + 1}_konumu"
        variable.type = "TRANSFORMS"
        target = variable.targets[0]
        target.id = controller
        target.transform_type = "LOC_X"
        target.transform_space = "WORLD_SPACE"

        if dependency_source is None:
            dependency_source = node.outputs[0]
        else:
            union = group.nodes.new("ShaderNodeMath")
            union.name = f"CR_Controller_Dependency_Union_{index:02d}"
            union.operation = "MULTIPLY"
            union.location = (-350, -210 - index * 70)
            group.links.new(dependency_source, union.inputs[0])
            group.links.new(node.outputs[0], union.inputs[1])
            dependency_source = union.outputs[0]

    for link in list(cube_amount.inputs[1].links):
        group.links.remove(link)
    group.links.new(dependency_source, cube_amount.inputs[1])


def _cleanup_legacy_character_system(scene):
    for obj in scene.objects:
        if "_cr_previous_pass_index" in obj:
            obj.pass_index = int(obj["_cr_previous_pass_index"])
            del obj["_cr_previous_pass_index"]

    for view_layer in scene.view_layers:
        for aov in list(view_layer.aovs):
            if aov.name == LEGACY_AOV_NAME:
                view_layer.aovs.remove(aov)

    for material in bpy.data.materials:
        tree = getattr(material, "node_tree", None)
        if tree is None:
            continue
        for node_name in LEGACY_MATERIAL_NODES:
            node = tree.nodes.get(node_name)
            if node:
                tree.nodes.remove(node)


def _drive_socket_from_object_amount(socket, obj):
    _assert_setup_is_safe()
    animation = socket.id_data.animation_data
    path = socket.path_from_id("default_value")
    existing = animation.drivers.find(path) if animation else None
    if obj is not None and existing is not None:
        variables = existing.driver.variables
        if (existing.driver.type == "AVERAGE" and len(variables) == 1
                and variables[0].type == "SINGLE_PROP"
                and variables[0].targets[0].id == obj
                and variables[0].targets[0].data_path == "cr_color_amount"):
            return
    try:
        socket.driver_remove("default_value")
    except (TypeError, RuntimeError):
        pass

    if obj is None:
        socket.default_value = 0.0
        return

    fcurve = socket.driver_add("default_value")
    driver = fcurve.driver
    driver.type = "AVERAGE"
    for old_variable in list(driver.variables):
        driver.variables.remove(old_variable)
    variable = driver.variables.new()
    variable.name = "renk_miktari"
    variable.type = "SINGLE_PROP"
    target = variable.targets[0]
    target.id = obj
    target.data_path = "cr_color_amount"


def _ensure_material_selected_mask(material, obj):
    if material is None:
        raise RuntimeError("Bos materyal yuvasina maske eklenemedi.")

    if not material.use_nodes:
        diffuse_color = tuple(material.diffuse_color)
        material.use_nodes = True
        principled = material.node_tree.nodes.get("Principled BSDF")
        if principled and principled.inputs.get("Base Color"):
            principled.inputs["Base Color"].default_value = diffuse_color

    tree = material.node_tree
    if tree is None:
        raise RuntimeError(f"{material.name} materyal node agaci acilamadi.")

    nodes = tree.nodes

    # Eski surumlerde nesne kimligi karsilastirilip kamera uzayinda bir
    # dikdortgen yedek maske uretiliyordu. Bu iki dugum yeni kopyada kalirsa
    # kullanicinin istedigi tam yuzey maskesi yerine eski davranis geri donebilir.
    for obsolete_name in SELECTED_MATERIAL_NODES[:2]:
        obsolete = nodes.get(obsolete_name)
        if obsolete is not None:
            nodes.remove(obsolete)

    aov_output = nodes.get(SELECTED_MATERIAL_NODES[2])
    if aov_output and aov_output.bl_idname != "ShaderNodeOutputAOV":
        nodes.remove(aov_output)
        aov_output = None
    if aov_output is None:
        aov_output = nodes.new("ShaderNodeOutputAOV")
        aov_output.name = SELECTED_MATERIAL_NODES[2]
    aov_output.label = "Secilen Nesnenin Tam Yuzey Maskesi"
    aov_output.aov_name = SELECTED_AOV_NAME
    aov_output.location = (-130, -420)
    aov_output.hide = True

    value_input = aov_output.inputs["Value"]
    for link in list(value_input.links):
        tree.links.remove(link)

    # Her materyal bu objeye ozel bir kopyadir. AOV siddetini objenin animasyonlu
    # renk miktarina baglamak, zamansal gecisi yumusatirken ekran uzayindaki
    # nesne siluetini her karede tamamen keskin tutar.
    _drive_socket_from_object_amount(value_input, obj)
    tree.update_tag()


def _new_default_mask_material(obj):
    material = bpy.data.materials.new(name=f"CR_Auto_{obj.name}")
    material.diffuse_color = tuple(obj.color)
    material.use_nodes = True
    principled = material.node_tree.nodes.get("Principled BSDF")
    if principled and principled.inputs.get("Base Color"):
        principled.inputs["Base Color"].default_value = tuple(obj.color)
    return material


def _ensure_object_mask_materials(obj):
    data = getattr(obj, "data", None)
    materials = getattr(data, "materials", None)
    if materials is None:
        raise RuntimeError(f"{obj.name} materyal desteklemiyor.")

    if len(obj.material_slots) == 0:
        return 0

    # Materyal kopyalari sadece bu objeye OBJECT override olarak atanir. Boylece
    # ayni mesh/materyali paylasan secilmemis objeler maskeye dahil olmaz.
    if SELECTED_MATERIAL_BACKUP in obj:
        current = [slot.material for slot in obj.material_slots]
        if all(
            material is None or material.get(SELECTED_MATERIAL_COPY_MARKER, False)
            for material in current
        ):
            for material in current:
                if material is not None:
                    _ensure_material_selected_mask(material, obj)
            return sum(material is not None for material in current)
        _restore_object_materials(obj)

    backup = [
        {
            "link": slot.link,
            "material": slot.material.name if slot.material is not None else "",
        }
        for slot in obj.material_slots
    ]
    obj[SELECTED_MATERIAL_BACKUP] = json.dumps(backup)

    created = []
    try:
        for index, slot in enumerate(obj.material_slots):
            source = slot.material
            material = source.copy() if source is not None else _new_default_mask_material(obj)
            material.name = f"CR_Color_{obj.name}_{index}_{material.name}"
            material[SELECTED_MATERIAL_COPY_MARKER] = True
            _ensure_material_selected_mask(material, obj)
            slot.link = "OBJECT"
            slot.material = material
            created.append(material)
    except Exception:
        _restore_object_materials(obj)
        for material in created:
            if material.users == 0:
                bpy.data.materials.remove(material)
        raise

    return len(created)


def _restore_object_materials(obj):
    raw_backup = obj.get(SELECTED_MATERIAL_BACKUP)
    if raw_backup is None:
        return

    try:
        backup = json.loads(str(raw_backup))
    except (TypeError, ValueError, json.JSONDecodeError):
        backup = []

    copied_materials = {
        slot.material
        for slot in obj.material_slots
        if slot.material is not None
        and slot.material.get(SELECTED_MATERIAL_COPY_MARKER, False)
    }

    for index, state in enumerate(backup):
        if index >= len(obj.material_slots) or not isinstance(state, dict):
            break
        slot = obj.material_slots[index]
        material_name = state.get("material", "")
        original = bpy.data.materials.get(material_name) if material_name else None
        link = state.get("link", "DATA")
        slot.link = link if link in {"DATA", "OBJECT"} else "DATA"
        slot.material = original

    del obj[SELECTED_MATERIAL_BACKUP]

    for material in copied_materials:
        if material.users == 0:
            bpy.data.materials.remove(material)


def _selected_color_targets(context):
    roots = []
    for selected in context.selected_objects:
        root = selected
        parent = selected.parent
        while parent is not None:
            if parent.type == "ARMATURE":
                root = parent
                break
            parent = parent.parent
        roots.append(root)

    targets = []
    seen = set()
    stack = list(roots)
    while stack:
        obj = stack.pop()
        if obj in seen:
            continue
        seen.add(obj)
        stack.extend(obj.children)
        if obj.type in {"MESH", "CURVE", "SURFACE", "META", "FONT", "VOLUME"}:
            if not obj.get(CONTROLLER_MARKER, False):
                targets.append(obj)
    return targets


def _valid_selected_group(value):
    try:
        index = int(value)
    except (TypeError, ValueError):
        return None
    return index if 0 <= index < MAX_SELECTED_GROUPS else None


def _next_selected_group(scene):
    used = {
        group_index
        for obj in _colored_objects(scene)
        if (group_index := _valid_selected_group(obj.get(SELECTED_GROUP_MARKER)))
        is not None
    }
    for index in range(MAX_SELECTED_GROUPS):
        if index not in used:
            return index
    raise RuntimeError(
        f"En fazla {MAX_SELECTED_GROUPS} ayri nesne/karakter renk animasyonu kullanilabilir."
    )


def _selected_group_for_targets(scene, targets):
    existing = {
        group_index
        for obj in targets
        if obj.get(SELECTED_MARKER, False)
        if (group_index := _valid_selected_group(obj.get(SELECTED_GROUP_MARKER)))
        is not None
    }
    return min(existing) if existing else _next_selected_group(scene)


def _mark_selected_color(obj, group_index):
    if SELECTED_PREVIOUS_PASS not in obj:
        obj[SELECTED_PREVIOUS_PASS] = int(obj.pass_index)
    obj[SELECTED_GROUP_MARKER] = int(group_index)
    obj.pass_index = SELECTED_PASS_INDEX + int(group_index)
    obj[SELECTED_MARKER] = True


def _unmark_selected_color(obj):
    _restore_object_materials(obj)
    if SELECTED_PREVIOUS_PASS in obj:
        obj.pass_index = int(obj[SELECTED_PREVIOUS_PASS])
        del obj[SELECTED_PREVIOUS_PASS]
    elif SELECTED_PASS_INDEX <= obj.pass_index < SELECTED_PASS_INDEX + MAX_SELECTED_GROUPS:
        obj.pass_index = 0
    if SELECTED_GROUP_MARKER in obj:
        del obj[SELECTED_GROUP_MARKER]
    if SELECTED_MARKER in obj:
        del obj[SELECTED_MARKER]


def _colored_objects(scene):
    return [obj for obj in scene.objects if obj.get(SELECTED_MARKER, False)]


def _color_group_root(obj):
    current = obj
    while current.parent is not None:
        current = current.parent
        if current.type == "ARMATURE":
            return current
    return obj


def _sync_selected_index_masks(scene, group=None):
    _assert_setup_is_safe(scene)
    if group is None:
        group_name = scene.get("cr_group_name", "")
        group = bpy.data.node_groups.get(group_name) if group_name else None
    if group is None:
        return {}

    colored = _colored_objects(scene)
    grouped = {}
    unassigned = {}

    for obj in colored:
        group_index = _valid_selected_group(obj.get(SELECTED_GROUP_MARKER))
        if group_index is None:
            unassigned.setdefault(_color_group_root(obj), []).append(obj)
        else:
            grouped.setdefault(group_index, []).append(obj)

    for members in unassigned.values():
        used = set(grouped)
        group_index = next(
            (index for index in range(MAX_SELECTED_GROUPS) if index not in used),
            None,
        )
        if group_index is None:
            break
        for obj in members:
            obj[SELECTED_GROUP_MARKER] = group_index
            obj.pass_index = SELECTED_PASS_INDEX + group_index
        grouped[group_index] = members

    for group_index in range(MAX_SELECTED_GROUPS):
        mask = group.nodes.get(f"CR_Selected_ID_Mask_{group_index:02d}")
        amount = group.nodes.get(f"CR_Selected_ID_Amount_{group_index:02d}")
        if mask is not None:
            mask.inputs["Index"].default_value = SELECTED_PASS_INDEX + group_index
        if amount is None:
            continue

        members = grouped.get(group_index, [])
        representative = members[0] if members else None
        for obj in members:
            if obj.pass_index != SELECTED_PASS_INDEX + group_index:
                obj.pass_index = SELECTED_PASS_INDEX + group_index
        _drive_socket_from_object_amount(amount.inputs[1], representative)

    group.update_tag()
    return grouped


def _sync_selected_cryptomatte_nodes(
    scene,
    tree,
    effect,
    view_layer_name,
    grouped,
):
    _assert_setup_is_safe(scene)
    if tree is None or effect is None:
        return

    layer_name = f"{view_layer_name}.CryptoObject"
    for group_index in range(MAX_SELECTED_GROUPS):
        node_name = f"{CRYPTOMATTE_NODE_PREFIX}{group_index:02d}"
        crypto = tree.nodes.get(node_name)
        members = grouped.get(group_index, [])
        if not members:
            if crypto is not None:
                tree.nodes.remove(crypto)
            continue
        if crypto is not None and crypto.bl_idname != "CompositorNodeCryptomatteV2":
            tree.nodes.remove(crypto)
            crypto = None
        if crypto is None:
            crypto = tree.nodes.new("CompositorNodeCryptomatteV2")
            crypto.name = node_name
            crypto.label = f"Cycles Karakter Maskesi {group_index + 1}"
            crypto.location = (-760, -300 - group_index * 110)

        crypto.source = "RENDER"
        crypto.scene = scene
        try:
            crypto.layer_name = layer_name
        except (AttributeError, TypeError, ValueError):
            pass

        crypto.matte_id = ",".join(sorted(obj.name for obj in members))

        crypto_input = effect.inputs.get(f"Crypto Mask {group_index:02d}")
        crypto_output = crypto.outputs.get("Matte")
        if crypto_input is None or crypto_output is None:
            continue
        if crypto_input.is_linked:
            for link in list(crypto_input.links):
                if link.from_socket != crypto_output:
                    tree.links.remove(link)
        if not crypto_input.is_linked:
            tree.links.new(crypto_output, crypto_input)

    tree.update_tag()


def _sync_selected_render_masks(
    scene,
    group=None,
    tree=None,
    effect=None,
    view_layer_name=None,
):
    grouped = _sync_selected_index_masks(scene, group)
    if tree is None:
        tree = scene.compositing_node_group
    if tree is None:
        return grouped
    if effect is None:
        effect = tree.nodes.get(EFFECT_NODE_NAME)
    if effect is None:
        return grouped
    if view_layer_name is None:
        view_layer_name = _effect_view_layer_name(scene)
    _sync_selected_cryptomatte_nodes(
        scene,
        tree,
        effect,
        view_layer_name,
        grouped,
    )
    return grouped


def _is_valid_controller(obj):
    if obj is None or obj.type in {"CAMERA", "LIGHT", "ARMATURE", "EMPTY"}:
        return False
    try:
        corners = list(obj.bound_box)
    except (AttributeError, RuntimeError):
        return False
    return len(corners) == 8


def _controllers(scene):
    primary = getattr(scene, "cr_controller", None)
    result = [
        obj for obj in scene.objects
        if _is_valid_controller(obj)
        and (obj.get(CONTROLLER_MARKER, False) or obj == primary)
    ]
    return result


def _remember_controller_display(obj):
    if "_cr_previous_hide_render" not in obj:
        obj["_cr_previous_hide_render"] = bool(obj.hide_render)
    if "_cr_previous_display_type" not in obj and hasattr(obj, "display_type"):
        obj["_cr_previous_display_type"] = obj.display_type
    if "_cr_previous_show_in_front" not in obj:
        obj["_cr_previous_show_in_front"] = bool(obj.show_in_front)
    if "_cr_previous_visible_camera" not in obj and hasattr(obj, "visible_camera"):
        obj["_cr_previous_visible_camera"] = bool(obj.visible_camera)
    if "_cr_previous_hide_viewport" not in obj:
        obj["_cr_previous_hide_viewport"] = bool(obj.hide_get())


def _set_controller(scene, obj, mode="COLOR"):
    _remember_controller_display(obj)
    obj[CONTROLLER_MARKER] = True
    obj[CONTROLLER_MODE] = "GRAY" if mode == "GRAY" else "COLOR"
    obj.hide_render = True
    if hasattr(obj, "visible_camera"):
        obj.visible_camera = False
    if hasattr(obj, "display_type"):
        obj.display_type = "BOUNDS"
    obj.show_in_front = True
    scene.cr_controller = obj
    obj.hide_set(True)


def _restore_controller(obj):
    if "_cr_previous_hide_render" in obj:
        obj.hide_render = bool(obj["_cr_previous_hide_render"])
        del obj["_cr_previous_hide_render"]
    if "_cr_previous_visible_camera" in obj and hasattr(obj, "visible_camera"):
        obj.visible_camera = bool(obj["_cr_previous_visible_camera"])
        del obj["_cr_previous_visible_camera"]
    if "_cr_previous_display_type" in obj and hasattr(obj, "display_type"):
        obj.display_type = str(obj["_cr_previous_display_type"])
        del obj["_cr_previous_display_type"]
    if "_cr_previous_show_in_front" in obj:
        obj.show_in_front = bool(obj["_cr_previous_show_in_front"])
        del obj["_cr_previous_show_in_front"]
    was_hidden = bool(obj.get("_cr_previous_hide_viewport", False))
    if "_cr_previous_hide_viewport" in obj:
        del obj["_cr_previous_hide_viewport"]
    obj.hide_set(was_hidden)
    if CONTROLLER_MARKER in obj:
        del obj[CONTROLLER_MARKER]
    if CONTROLLER_MODE in obj:
        del obj[CONTROLLER_MODE]


def _controller_volume(scene, controller, depsgraph=None, margin=None):
    evaluated = controller
    if depsgraph is not None:
        try:
            evaluated = controller.evaluated_get(depsgraph)
        except (ReferenceError, RuntimeError):
            evaluated = controller

    matrix = evaluated.matrix_world
    corners = getattr(evaluated, "bound_box", controller.bound_box)
    local_corners = [Vector(corner) for corner in corners]
    if not local_corners:
        return None

    local_min = Vector(tuple(min(corner[index] for corner in local_corners)
                             for index in range(3)))
    local_max = Vector(tuple(max(corner[index] for corner in local_corners)
                             for index in range(3)))
    local_center = (local_min + local_max) * 0.5
    local_half = (local_max - local_min) * 0.5

    if margin is None:
        margin = scene.cr_mask_margin

    basis = matrix.to_3x3()
    axes = []
    half_extents = []
    for index in range(3):
        vector = basis.col[index].copy()
        scale = vector.length
        if scale <= 0.000001 or local_half[index] <= 0.000001:
            return None
        axes.append(tuple(vector.normalized()))
        half_extents.append(max(0.0001, local_half[index] * scale * margin))

    return tuple(matrix @ local_center), tuple(axes), tuple(half_extents)


def _volume_falloff_constants(scene):
    # Eski piksel tabanli 0..1000 araligini, kameradan bagimsiz olarak kupun
    # yari boyutunun 0..100%'u araligina cevirir. 140 degeri %14 yumusakliktir.
    softness = min(0.95, max(0.000001, float(scene.cr_feather) / 1000.0))
    width = 2.0 * softness
    return 1.0 / width, -(1.0 - softness) / width


def _update_group_settings(scene):
    group_name = scene.get("cr_group_name", "")
    group = bpy.data.node_groups.get(group_name) if group_name else None
    if not group:
        return

    changed = False
    active_camera_mode = _camera_mode(_active_camera_for_frame(scene))

    grayscale = group.nodes.get("CR_Grayscale")
    if grayscale:
        changed |= _set_scalar_socket(
            grayscale.inputs["Saturation"],
            0.0 if active_camera_mode == "GRAY" else scene.cr_outside_saturation,
        )

    yellow_filter = group.nodes.get("CR_Yellow_Filter")
    if yellow_filter:
        yellow_factor = _socket_by_identifier(yellow_filter.inputs, "Fac")
        changed |= _set_scalar_socket(
            yellow_factor,
            scene.cr_yellow_filter,
        )

    purple_filter = group.nodes.get("CR_Purple_Filter")
    if purple_filter:
        purple_factor = _socket_by_identifier(purple_filter.inputs, "Fac")
        changed |= _set_scalar_socket(
            purple_factor,
            scene.cr_purple_filter,
        )

    multiplier, addend = _volume_falloff_constants(scene)
    for index in range(int(group.get("cr_controller_count", 0))):
        falloff = group.nodes.get(_volume_node_name(index, "Falloff_Normalize"))
        if falloff is None:
            continue
        changed |= _set_scalar_socket(falloff.inputs[1], multiplier)
        changed |= _set_scalar_socket(falloff.inputs[2], addend)

    cube_amount = group.nodes.get("CR_Cube_Color_Amount")
    if cube_amount:
        changed |= _set_scalar_socket(
            cube_amount.inputs[0],
            scene.cr_cube_color_amount,
        )

    full_scene_mask = group.nodes.get("CR_Full_Scene_Mask")
    if full_scene_mask:
        changed |= _set_scalar_socket(
            full_scene_mask.inputs[1],
            0.0 if active_camera_mode == "GRAY" else scene.cr_full_scene_color_amount,
        )
    camera_color = group.nodes.get("CR_Camera_Color_Mode")
    if camera_color:
        changed |= _set_scalar_socket(
            camera_color.inputs[0],
            1.0 if active_camera_mode == "COLOR" else 0.0,
        )

    camera_gray = group.nodes.get("CR_Camera_Gray_Mode")
    if camera_gray:
        changed |= _set_scalar_socket(
            camera_gray.inputs[0],
            1.0 if active_camera_mode == "GRAY" else 0.0,
        )

    object_strength = group.nodes.get("CR_Object_Mode_Strength")
    if object_strength:
        changed |= _set_scalar_socket(
            object_strength.inputs[1],
            1.0,
        )

    if changed:
        _tag_compositor_update(scene, group)
    return changed


def _sync_object_mask(scene, depsgraph=None):
    global _SYNCING
    if _SYNCING:
        return

    controllers = _controllers(scene)
    group_name = scene.get("cr_group_name", "")
    group = bpy.data.node_groups.get(group_name) if group_name else None
    if group is None:
        return
    if int(group.get("cr_controller_count", -1)) != len(controllers):
        return False

    _SYNCING = True
    try:
        changed = False
        for index, controller in enumerate(controllers):
            offset = group.nodes.get(_volume_node_name(index, "Offset"))
            if offset is None:
                continue
            volume = _controller_volume(scene, controller, depsgraph)
            if volume is None:
                changed |= _set_vector_socket(
                    offset.inputs[1], 1000000.0, 1000000.0, 1000000.0,
                )
                continue

            center, axes, half_extents = volume
            changed |= _set_vector_socket(offset.inputs[1], *center)
            for axis_name, axis, half_extent in zip("XYZ", axes, half_extents):
                dot = group.nodes.get(_volume_node_name(index, f"Dot_{axis_name}"))
                normalize = group.nodes.get(
                    _volume_node_name(index, f"Normalize_{axis_name}")
                )
                if dot is not None:
                    changed |= _set_vector_socket(dot.inputs[1], *axis)
                if normalize is not None:
                    changed |= _set_scalar_socket(normalize.inputs[1], half_extent)
        if changed:
            _tag_compositor_update(scene, group)
        return changed
    finally:
        _SYNCING = False


def _settings_update(self, context):
    if _render_in_progress():
        return
    scene = self if isinstance(self, bpy.types.Scene) else context.scene
    _update_group_settings(scene)
    _sync_object_mask(scene)


def _scene_has_effect_data(scene):
    tree = scene.compositing_node_group
    return bool(
        scene.get("cr_group_name", "")
        or (tree is not None and tree.nodes.get(EFFECT_NODE_NAME) is not None)
        or any(obj.get(SELECTED_MARKER, False) for obj in scene.objects)
        or bool(_controllers(scene))
        or any(
            obj.type == "CAMERA" and _camera_mode(obj) != "NORMAL"
            for obj in scene.objects
        )
    )


def _effect_needs_prepare(scene):
    if not scene.render.use_compositing:
        return True

    tree = scene.compositing_node_group
    if tree is None:
        return True

    effect = tree.nodes.get(EFFECT_NODE_NAME)
    pass_node = tree.nodes.get(PASS_NODE_NAME)
    group_name = scene.get("cr_group_name", "")
    group = bpy.data.node_groups.get(group_name) if group_name else None
    if (
        effect is None
        or pass_node is None
        or group is None
        or group.get("cr_api_version") != GROUP_API_VERSION
        or int(group.get("cr_controller_count", -1)) != len(_controllers(scene))
        or group.get("cr_controller_signature", "") != _controller_signature(scene)
        or effect.node_tree != group
    ):
        return True
    if not _controller_dependency_ready(scene, group):
        return True

    output = next((node for node in tree.nodes
                   if node.bl_idname == "NodeGroupOutput" and node.is_active_output), None)
    if output is None:
        return True
    output_image = output.inputs.get("Image")
    if (
        output_image is None
        or not output_image.is_linked
        or output_image.links[0].from_node != effect
    ):
        return True

    object_mask_input = effect.inputs.get("Object Mask")
    if object_mask_input is None or not object_mask_input.is_linked:
        return True

    position_output = pass_node.outputs.get("Position")
    position_input = effect.inputs.get("Position")
    if (
        position_output is None
        or position_input is None
        or not position_input.is_linked
        or position_input.links[0].from_socket != position_output
    ):
        return True

    # Object Index soketi yalniz Cycles aktifken kesin olarak olusur. Motor
    # degistirildiginde render baslamadan once dugumu ve baglantiyi yenile.
    if scene.render.engine == "CYCLES":
        object_index_output = _object_index_output(pass_node)
        object_index_input = effect.inputs.get("Object Index")
        if (
            object_index_output is None
            or object_index_input is None
            or not object_index_input.is_linked
            or object_index_input.links[0].from_socket != object_index_output
        ):
            return True

    return False


def _effect_view_layer_name(scene):
    tree = scene.compositing_node_group
    pass_node = tree.nodes.get(PASS_NODE_NAME) if tree is not None else None
    if pass_node is not None and getattr(pass_node, "layer", ""):
        return pass_node.layer
    return scene.view_layers[0].name


def _prepare_existing_effect(scene, force=False):
    global _PREPARING
    _assert_setup_is_safe(scene)
    if _PREPARING or not _scene_has_effect_data(scene):
        return False
    if not force and not _effect_needs_prepare(scene):
        return False

    _PREPARING = True
    try:
        _ensure_effect(scene, _effect_view_layer_name(scene))
        _update_group_settings(scene)
        _sync_object_mask(scene)
        _tag_compositor_update(scene, _get_group(scene))
        return True
    finally:
        _PREPARING = False


def _sync_render_values(scene, depsgraph=None):
    """Only existing compositor values; never IDs, topology or drivers.

    Render callbacks may run on a worker with an evaluated scene. The UI must
    have been locked BEFORE the render job starts to avoid concurrent drawing.
    Animated object amounts are evaluated by their existing native drivers.
    """
    if not bpy.app.background and not scene.render.use_lock_interface:
        return
    group_name = scene.get("cr_group_name", "")
    group = bpy.data.node_groups.get(group_name) if group_name else None
    if group is None or group.get("cr_api_version") != GROUP_API_VERSION:
        return
    changed = _update_group_settings(scene)
    changed = _sync_object_mask(scene, depsgraph) or changed
    return changed


@persistent
def _cr_frame_change(scene, depsgraph=None):
    global _FRAME_DIRTY
    _FRAME_DIRTY = True
    # Timeline Camera Marker aktif kamerayi bu karede degistirebilir. Kamera
    # modu ayni karede yazilir; eski kameranin sonucu bir kare daha kalmaz.
    _update_group_settings(scene)
    if _render_in_progress():
        _sync_object_mask(scene, depsgraph)


@persistent
def _cr_depsgraph_changed(scene, depsgraph=None):
    # A depsgraph callback must not trigger another structural rebuild.
    global _FRAME_DIRTY
    _FRAME_DIRTY = True


@persistent
def _cr_render_started(scene):
    global _RENDERING
    _RENDERING = True
    if _scene_has_effect_data(scene) and _effect_needs_prepare(scene):
        print("barismsi: Efekt hazir degil. Renderi durdurup Cycles Renderini Yenile'ye basin.")
    if not bpy.app.background and not scene.render.use_lock_interface:
        print("barismsi: Lock Interface kapali; render sirasinda maske guncellenmeyecek.")


@persistent
def _cr_render_prepare(scene):
    # DO NOT call _ensure_effect / _prepare_existing_effect here. The previous
    # version wrote obj.pass_index on the render worker and crashed Blender.
    # frame_change_post receives the current render depsgraph. render_pre is
    # earlier and may still expose the previous frame's controller transform.
    pass


@persistent
def _cr_render_finished(scene):
    global _RENDERING, _FRAME_DIRTY, _PREVIEW_RESTORE_PENDING
    _RENDERING = False
    _FRAME_DIRTY = True
    if _PREVIEW_RENDER_STATE is not None:
        # render_complete/render_cancel can run outside the main UI thread.
        # The persistent idle timer restores preview settings safely.
        _PREVIEW_RESTORE_PENDING = True


@persistent
def _cr_load_post(_dummy):
    global _RENDERING, _FRAME_DIRTY, _PREVIEW_RENDER_STATE, _PREVIEW_RESTORE_PENDING
    _RENDERING = False
    _FRAME_DIRTY = True
    _PREVIEW_RENDER_STATE = None
    _PREVIEW_RESTORE_PENDING = False


def _restore_preview_render_settings():
    global _PREVIEW_RENDER_STATE, _PREVIEW_RESTORE_PENDING
    state = _PREVIEW_RENDER_STATE
    if state is None:
        _PREVIEW_RESTORE_PENDING = False
        return True
    if _render_in_progress() or threading.current_thread() is not threading.main_thread():
        return False

    scene = bpy.data.scenes.get(state["scene"])
    if scene is not None:
        scene.render.resolution_percentage = state["resolution_percentage"]
        if hasattr(scene, "cycles"):
            scene.cycles.samples = state["cycles_samples"]
    _PREVIEW_RENDER_STATE = None
    _PREVIEW_RESTORE_PENDING = False
    return True


def _cr_initialize_existing_scenes():
    """Main-thread idle timer: structural preparation never runs in a handler."""
    global _FRAME_DIRTY
    if not _REGISTERED:
        return None
    if _render_in_progress():
        return 0.25
    wm = getattr(bpy.context, "window_manager", None)
    if wm is not None and wm.is_interface_locked:
        return 0.25
    try:
        scenes = list(bpy.data.scenes)
    except (AttributeError, RuntimeError):
        # Preferences installation temporarily exposes _RestrictData.
        return 0.25

    if _PREVIEW_RESTORE_PENDING:
        _restore_preview_render_settings()

    dirty = _FRAME_DIRTY
    _FRAME_DIRTY = False
    for scene in scenes:
        try:
            if not _scene_has_effect_data(scene):
                continue
            if not scene.render.use_lock_interface:
                scene.render.use_lock_interface = True
            prepared = _prepare_existing_effect(scene)
            if dirty or prepared:
                graph = (bpy.context.evaluated_depsgraph_get()
                         if scene == bpy.context.scene else None)
                _update_group_settings(scene)
                _sync_object_mask(scene, graph)
        except Exception as exc:
            print(f"barismsi Color Reveal bos zaman yenileme: {exc}")
    return 0.25


class CR_OT_setup_from_selected(Operator):
    bl_idname = "cr.setup_from_selected"
    bl_label = "Secili Objeleri Efekt Alani Yap"
    bl_description = (
        "Secili tum kup/mesh objelerini ayri gorunmez renkli veya renksiz hacimler olarak ekler"
    )
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(
        name="Kup Modu",
        items=(
            ("COLOR", "Renkli Alan", "Kup icindeki gorunen yuzeyleri renkli yapar"),
            ("GRAY", "Renksiz Alan", "Kup icindeki gorunen yuzeyleri renksiz yapar"),
        ),
        default="COLOR",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = context.scene
        controllers = [
            obj for obj in context.selected_objects
            if _is_valid_controller(obj) and not obj.get(SELECTED_MARKER, False)
        ]

        if scene.camera is None:
            self.report({"ERROR"}, "Once sahneye aktif bir kamera atayin.")
            return {"CANCELLED"}
        if not controllers:
            self.report({"ERROR"}, "Bir veya daha fazla Cube/mesh obje secin.")
            return {"CANCELLED"}
        existing = set(_controllers(scene))
        new_controllers = [obj for obj in controllers if obj not in existing]
        if len(existing) + len(new_controllers) > MAX_CONTROLLERS:
            self.report({"ERROR"}, f"En fazla {MAX_CONTROLLERS} kontrol kupu kullanilabilir.")
            return {"CANCELLED"}

        try:
            _cleanup_legacy_character_system(scene)
            for controller in controllers:
                _set_controller(scene, controller, self.mode)
            if context.active_object in controllers:
                scene.cr_controller = context.active_object
            _ensure_effect(scene, context.view_layer.name)
            _update_group_settings(scene)
            context.view_layer.update()
            _sync_object_mask(scene, context.evaluated_depsgraph_get())
            preview_count = _enable_live_preview(context)
        except Exception as exc:
            self.report({"ERROR"}, f"Kurulum basarisiz: {exc}")
            return {"CANCELLED"}

        mode_label = "renksiz" if self.mode == "GRAY" else "renkli"
        message = f"{len(controllers)} kup {mode_label} efekt alanina eklendi ve gizlendi."
        if preview_count:
            message += " Canli onizleme acildi."
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CR_OT_set_camera_mode(Operator):
    bl_idname = "cr.set_camera_mode"
    bl_label = "Kamera Renk Modunu Ayarla"
    bl_description = "Secili kameraya ozel renk modunu kaydeder"
    bl_options = {"REGISTER", "UNDO"}

    mode: EnumProperty(
        name="Kamera Modu",
        items=(
            ("NORMAL", "Normal Efekt", "Kup ve nesne maskelerini normal kullanir"),
            ("COLOR", "Kamera Renkli", "Bu kamera aktifken tum goruntuyu renkli yapar"),
            ("GRAY", "Kamera Renksiz", "Bu kamerada tabani renksiz yapar; renkli kupler ve nesneler korunur"),
        ),
        default="NORMAL",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = context.scene
        selected = context.active_object
        camera = selected if selected is not None and selected.type == "CAMERA" else scene.camera
        if camera is None:
            self.report({"ERROR"}, "Bir kamera secin veya sahneye aktif kamera atayin.")
            return {"CANCELLED"}

        try:
            if scene.camera is None:
                scene.camera = camera
            camera[CAMERA_MODE] = self.mode
            _cleanup_legacy_character_system(scene)
            _ensure_effect(scene, context.view_layer.name)
            _update_group_settings(scene)
            _sync_object_mask(scene, context.evaluated_depsgraph_get())
            _tag_compositor_update(scene)
            _enable_live_preview(context)
        except Exception as exc:
            self.report({"ERROR"}, f"Kamera modu kurulamadi: {exc}")
            return {"CANCELLED"}
        labels = {
            "NORMAL": "normal efekt",
            "COLOR": "tam renkli",
            "GRAY": "taban renksiz",
        }
        self.report({"INFO"}, f"{camera.name}: {labels[self.mode]} modu kaydedildi.")
        return {"FINISHED"}


class CR_OT_enable_live_preview(Operator):
    bl_idname = "cr.enable_live_preview"
    bl_label = "Canli Onizlemeyi Ac"
    bl_description = (
        "Bu 3D gorunumu aktif kameraya, Rendered moda ve Viewport Compositor'a gecirir"
    )

    def execute(self, context):
        if context.scene.camera is None:
            self.report({"ERROR"}, "Once sahneye aktif bir kamera atayin.")
            return {"CANCELLED"}

        if _enable_live_preview(context) == 0:
            self.report({"ERROR"}, "Bu dugmeyi bir 3D Viewport panelinden calistirin.")
            return {"CANCELLED"}

        _sync_object_mask(context.scene, context.evaluated_depsgraph_get())
        self.report({"INFO"}, "Kamera + Rendered + Viewport Compositor acildi.")
        return {"FINISHED"}


class CR_OT_select_controller(Operator):
    bl_idname = "cr.select_controller"
    bl_label = "Kupleri Goster ve Sec"
    bl_description = "Tum kontrol kuplerini sinir kutusu olarak gosterir ve secer"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if context.mode != "OBJECT":
            self.report({"WARNING"}, "Once Object Mode'a gecin.")
            return {"CANCELLED"}

        controllers = _controllers(context.scene)
        if not controllers:
            self.report({"WARNING"}, "Henuz gecerli bir efekt objesi secilmedi.")
            return {"CANCELLED"}

        bpy.ops.object.select_all(action="DESELECT")
        for controller in controllers:
            controller.hide_set(False)
            controller.hide_render = True
            if hasattr(controller, "visible_camera"):
                controller.visible_camera = False
            if hasattr(controller, "display_type"):
                controller.display_type = "BOUNDS"
            controller.show_in_front = True
            controller.select_set(True)
        context.view_layer.objects.active = context.scene.cr_controller or controllers[0]
        context.view_layer.update()
        _sync_object_mask(context.scene, context.evaluated_depsgraph_get())
        return {"FINISHED"}


class CR_OT_hide_controller(Operator):
    bl_idname = "cr.hide_controller"
    bl_label = "Kupleri Gizle"
    bl_description = "Temiz onizleme icin tum kontrol kuplerini 3D Viewport'ta gizler"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        controllers = _controllers(context.scene)
        if not controllers:
            self.report({"WARNING"}, "Henuz gecerli bir efekt objesi secilmedi.")
            return {"CANCELLED"}

        _sync_object_mask(context.scene, context.evaluated_depsgraph_get())
        for controller in controllers:
            controller.hide_render = True
            if hasattr(controller, "visible_camera"):
                controller.visible_camera = False
            controller.hide_set(True)
        self.report({"INFO"}, f"{len(controllers)} kontrol kupu gizlendi; efekt suruyor.")
        return {"FINISHED"}


class CR_OT_remove_controllers(Operator):
    bl_idname = "cr.remove_controllers"
    bl_label = "Kontrol Kuplerini Cikar"
    bl_description = "Secili kontrol kuplerini veya tum kontrol kuplerini efekt alanindan cikarir"
    bl_options = {"REGISTER", "UNDO"}

    all: BoolProperty(
        name="Tumunu Cikar",
        default=False,
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = context.scene
        controllers = _controllers(scene)
        selected = set(context.selected_objects)
        targets = controllers if self.all else [obj for obj in controllers if obj in selected]
        if not targets:
            self.report({"WARNING"}, "Cikarilacak kontrol kupu secilmedi.")
            return {"CANCELLED"}

        try:
            for controller in targets:
                _restore_controller(controller)
            if scene.cr_controller in targets:
                scene.cr_controller = None
            remaining = _controllers(scene)
            scene.cr_controller = remaining[0] if remaining else None
            _ensure_effect(scene, context.view_layer.name)
            _update_group_settings(scene)
            context.view_layer.update()
            _sync_object_mask(scene, context.evaluated_depsgraph_get())
            _tag_compositor_update(scene, _get_group(scene))
        except Exception as exc:
            self.report({"ERROR"}, f"Kontrol kupu cikarilamadi: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"{len(targets)} kontrol kupu efekt alanindan cikarildi.")
        return {"FINISHED"}


class CR_OT_add_selected_color(Operator):
    bl_idname = "cr.add_selected_color"
    bl_label = "Secilenleri Renkli Tut"
    bl_description = (
        "Secili karakter veya esyayi, armature bagli tum mesh parcalariyla birlikte renkli tutar"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        if _PREVIEW_RENDER_STATE is not None and not _render_in_progress():
            _restore_preview_render_settings()
        if scene.camera is None:
            self.report({"ERROR"}, "Once sahneye aktif bir kamera atayin.")
            return {"CANCELLED"}

        targets = _selected_color_targets(context)
        if not targets:
            self.report({"ERROR"}, "Bir karakter, armature veya esya secin.")
            return {"CANCELLED"}

        added = 0
        failed = []
        try:
            _cleanup_legacy_character_system(scene)
            _ensure_selected_aov(scene, context.view_layer.name)
            selected_group = _selected_group_for_targets(scene, targets)

            for obj in targets:
                try:
                    material_count = _ensure_object_mask_materials(obj)
                    if material_count == 0:
                        raise RuntimeError("Materyal yuvasi bulunamadi.")
                    existing_group = _valid_selected_group(
                        obj.get(SELECTED_GROUP_MARKER)
                    )
                    _mark_selected_color(
                        obj,
                        existing_group
                        if existing_group is not None
                        else selected_group,
                    )
                    added += 1
                except Exception as exc:
                    _unmark_selected_color(obj)
                    failed.append(f"{obj.name}: {exc}")

            _ensure_effect(scene, context.view_layer.name)
            _update_group_settings(scene)
            context.view_layer.update()
            _tag_compositor_update(scene, _get_group(scene))
            preview_count = _enable_live_preview(context)
        except Exception as exc:
            self.report({"ERROR"}, f"Nesne efekti kurulamadi: {exc}")
            return {"CANCELLED"}

        message = f"{added} parca renkli tutulacak. Cevre siyah-beyaz."
        if failed:
            message += f" {len(failed)} parca atlandi: {failed[0]}"
        if preview_count:
            message += " Canli onizleme acildi."
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CR_OT_keyframe_selected_amount(Operator):
    bl_idname = "cr.keyframe_selected_amount"
    bl_label = "Renk Miktari Keyframe Ekle"
    bl_description = (
        "Secili ve renk listesine eklenmis karakter/esyaya bu karede renk miktari keyframe'i ekler"
    )
    bl_options = {"REGISTER", "UNDO"}

    amount: FloatProperty(
        name="Renk Miktari",
        default=1.0,
        min=0.0,
        max=1.0,
        options={"SKIP_SAVE"},
    )
    use_panel_amount: BoolProperty(
        name="Panel Degerini Kullan",
        default=False,
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = context.scene
        targets = [
            obj
            for obj in _selected_color_targets(context)
            if obj.get(SELECTED_MARKER, False)
        ]
        if not targets:
            self.report(
                {"ERROR"},
                "Once nesneyi secip 'Secilenleri Renkli Tut' ile listeye ekleyin.",
            )
            return {"CANCELLED"}

        amount = scene.cr_animation_amount if self.use_panel_amount else self.amount
        amount = max(0.0, min(1.0, float(amount)))
        scene.cr_animation_amount = amount

        edit_preferences = context.preferences.edit
        previous_interpolation = getattr(
            edit_preferences,
            "keyframe_new_interpolation_type",
            None,
        )
        previous_handle = getattr(edit_preferences, "keyframe_new_handle_type", None)

        keyed = 0
        failed = []
        try:
            if previous_interpolation is not None:
                edit_preferences.keyframe_new_interpolation_type = "BEZIER"
            if previous_handle is not None:
                edit_preferences.keyframe_new_handle_type = "AUTO_CLAMPED"

            for obj in targets:
                try:
                    if _ensure_object_mask_materials(obj) == 0:
                        raise RuntimeError("Materyal yuvasi bulunamadi.")
                    obj.cr_color_amount = amount
                    if not obj.keyframe_insert(
                        data_path="cr_color_amount",
                        frame=scene.frame_current,
                        group="Renk Efekti",
                    ):
                        raise RuntimeError("Keyframe eklenemedi.")
                    keyed += 1
                except Exception as exc:
                    failed.append(f"{obj.name}: {exc}")
        finally:
            if previous_interpolation is not None:
                edit_preferences.keyframe_new_interpolation_type = previous_interpolation
            if previous_handle is not None:
                edit_preferences.keyframe_new_handle_type = previous_handle

        if keyed == 0:
            self.report({"ERROR"}, "Secilen parcalara keyframe eklenemedi.")
            return {"CANCELLED"}

        context.view_layer.update()
        _update_group_settings(scene)
        group = _get_group(scene)
        _sync_selected_render_masks(scene, group)
        _tag_compositor_update(scene, group)
        _enable_live_preview(context)

        state = "renkli" if amount >= 0.999 else "renksiz" if amount <= 0.001 else f"%{round(amount * 100)} renkli"
        message = f"{scene.frame_current}. kare: {keyed} parca {state}."
        if failed:
            message += f" {len(failed)} parca atlandi: {failed[0]}"
        self.report({"INFO"}, message)
        return {"FINISHED"}


class CR_OT_keyframe_area_amount(Operator):
    bl_idname = "cr.keyframe_area_amount"
    bl_label = "Alan Rengi Keyframe Ekle"
    bl_description = "Kup hacmine veya tum sahneye bu karede renk miktari keyframe'i ekler"
    bl_options = {"REGISTER", "UNDO"}

    amount: FloatProperty(
        name="Renk Miktari",
        default=1.0,
        min=0.0,
        max=1.0,
        options={"SKIP_SAVE"},
    )
    full_scene: BoolProperty(
        name="Tum Sahne",
        default=False,
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = context.scene
        if scene.camera is None:
            self.report({"ERROR"}, "Once sahneye aktif bir kamera atayin.")
            return {"CANCELLED"}
        if not self.full_scene and not _is_valid_controller(scene.cr_controller):
            self.report({"ERROR"}, "Once bir Cube'u efekt alani yapin.")
            return {"CANCELLED"}
        if _render_in_progress():
            self.report({"ERROR"}, "Render surerken keyframe eklenemez.")
            return {"CANCELLED"}

        data_path = (
            "cr_full_scene_color_amount"
            if self.full_scene
            else "cr_cube_color_amount"
        )
        amount = max(0.0, min(1.0, float(self.amount)))
        edit_preferences = context.preferences.edit
        previous_interpolation = getattr(
            edit_preferences, "keyframe_new_interpolation_type", None,
        )
        previous_handle = getattr(edit_preferences, "keyframe_new_handle_type", None)

        try:
            _ensure_effect(scene, context.view_layer.name)
            if previous_interpolation is not None:
                edit_preferences.keyframe_new_interpolation_type = "BEZIER"
            if previous_handle is not None:
                edit_preferences.keyframe_new_handle_type = "AUTO_CLAMPED"
            setattr(scene, data_path, amount)
            if not scene.keyframe_insert(
                data_path=data_path,
                frame=scene.frame_current,
                group="Renk Efekti",
            ):
                raise RuntimeError("Keyframe eklenemedi.")
        except Exception as exc:
            self.report({"ERROR"}, f"Alan keyframe'i eklenemedi: {exc}")
            return {"CANCELLED"}
        finally:
            if previous_interpolation is not None:
                edit_preferences.keyframe_new_interpolation_type = previous_interpolation
            if previous_handle is not None:
                edit_preferences.keyframe_new_handle_type = previous_handle

        _update_group_settings(scene)
        _tag_compositor_update(scene, _get_group(scene))
        _enable_live_preview(context)
        target = "Tum sahne" if self.full_scene else "Kup alani"
        state = "renkli" if amount >= 0.999 else "renksiz" if amount <= 0.001 else f"%{round(amount * 100)} renkli"
        self.report({"INFO"}, f"{scene.frame_current}. kare: {target} {state}.")
        return {"FINISHED"}


def _set_keyframes_constant(id_data, data_path):
    """Set a property's keys to exact switches in Blender's layered Action API."""
    animation = getattr(id_data, "animation_data", None)
    action = animation.action if animation else None
    if action is None:
        return False

    fcurves = []
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        fcurves.extend(legacy)
    for layer in getattr(action, "layers", []):
        for strip in layer.strips:
            for channelbag in getattr(strip, "channelbags", []):
                fcurves.extend(channelbag.fcurves)

    changed = False
    for fcurve in fcurves:
        if fcurve.data_path != data_path:
            continue
        for point in fcurve.keyframe_points:
            point.interpolation = "CONSTANT"
            changed = True
        fcurve.update()
    return changed


class CR_OT_keyframe_motion_blur(Operator):
    bl_idname = "cr.keyframe_motion_blur"
    bl_label = "Motion Blur Keyframe Ekle"
    bl_description = "Motion Blur'u bu karede shutter 0 veya ayarlanan degerle anahtarlar"
    bl_options = {"REGISTER", "UNDO"}

    enable: BoolProperty(
        name="Motion Blur Acik",
        default=True,
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        scene = context.scene
        scene.render.use_motion_blur = True
        value = float(scene.cr_motion_blur_shutter) if self.enable else 0.0
        scene.render.motion_blur_shutter = value
        if not scene.keyframe_insert(
            data_path="render.motion_blur_shutter",
            frame=scene.frame_current,
            group="Motion Blur",
        ):
            self.report({"ERROR"}, "Motion Blur keyframe'i eklenemedi.")
            return {"CANCELLED"}
        _set_keyframes_constant(scene, "render.motion_blur_shutter")
        state = f"acik (Shutter {value:.2f})" if self.enable else "kapali"
        self.report({"INFO"}, f"{scene.frame_current}. karede Motion Blur {state}.")
        return {"FINISHED"}


class CR_OT_remove_selected_color(Operator):
    bl_idname = "cr.remove_selected_color"
    bl_label = "Secilenleri Listeden Cikar"
    bl_description = "Secili karakter veya esyanin renkli kalma ozelligini kaldirir"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        targets = _selected_color_targets(context)
        removed = 0
        for obj in targets:
            if obj.get(SELECTED_MARKER, False):
                _unmark_selected_color(obj)
                removed += 1

        if removed == 0:
            self.report({"WARNING"}, "Secimde renkli listesine eklenmis nesne yok.")
            return {"CANCELLED"}

        context.view_layer.update()
        _sync_selected_render_masks(context.scene, _get_group(context.scene))
        _tag_compositor_update(context.scene, _get_group(context.scene))
        self.report({"INFO"}, f"{removed} parca renkli listesinden cikarildi.")
        return {"FINISHED"}


class CR_OT_clear_selected_color(Operator):
    bl_idname = "cr.clear_selected_color"
    bl_label = "Renkli Listeyi Temizle"
    bl_description = "Renkli tutulmak uzere isaretlenen tum karakter ve esyalari temizler"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        colored = _colored_objects(context.scene)
        for obj in colored:
            _unmark_selected_color(obj)

        context.view_layer.update()
        _sync_selected_render_masks(context.scene, _get_group(context.scene))
        _tag_compositor_update(context.scene, _get_group(context.scene))
        self.report({"INFO"}, f"Renkli liste temizlendi ({len(colored)} parca).")
        return {"FINISHED"}


class CR_OT_refresh_cycles_render(Operator):
    bl_idname = "cr.refresh_cycles_render"
    bl_label = "Cycles Renderini Yenile"
    bl_description = (
        "Mevcut sahnede compositor, AOV, Object Index ve Cryptomatte baglantilarini yeniden kurar"
    )
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        if _PREVIEW_RENDER_STATE is not None and not _render_in_progress():
            _restore_preview_render_settings()
        if scene.camera is None:
            self.report({"ERROR"}, "Once sahneye aktif bir kamera atayin.")
            return {"CANCELLED"}
        if not _scene_has_effect_data(scene):
            self.report(
                {"ERROR"},
                "Once bir kup efekt alani veya renkli karakter/esya ekleyin.",
            )
            return {"CANCELLED"}

        try:
            _assert_setup_is_safe(scene)
            for obj in _colored_objects(scene):
                _ensure_object_mask_materials(obj)
            _ensure_effect(scene, context.view_layer.name)
            _update_group_settings(scene)
            context.view_layer.update()
            _sync_object_mask(scene, context.evaluated_depsgraph_get())
            _tag_compositor_update(scene, _get_group(scene))

            if scene.render.engine == "CYCLES":
                tree = scene.compositing_node_group
                effect = tree.nodes.get(EFFECT_NODE_NAME)
                pass_node = tree.nodes.get(PASS_NODE_NAME)
                object_index = _object_index_output(pass_node) if pass_node else None
                object_input = effect.inputs.get("Object Index") if effect else None
                if (
                    object_index is None
                    or object_input is None
                    or not object_input.is_linked
                ):
                    raise RuntimeError("Cycles Object Index baglantisi olusmadi.")
                active_groups = {_valid_selected_group(obj.get(SELECTED_GROUP_MARKER))
                                 for obj in _colored_objects(scene)}
                for group_index in active_groups:
                    if group_index is None:
                        raise RuntimeError("Renk grubuna atanmamis nesne var.")
                    crypto = tree.nodes.get(f"{CRYPTOMATTE_NODE_PREFIX}{group_index:02d}")
                    crypto_input = effect.inputs.get(f"Crypto Mask {group_index:02d}")
                    if (
                        crypto is None
                        or not crypto.matte_id
                        or crypto_input is None
                        or not crypto_input.is_linked
                    ):
                        raise RuntimeError(f"Cycles Cryptomatte grup {group_index} baglantisi olusmadi.")
        except Exception as exc:
            self.report({"ERROR"}, f"Cycles yenileme basarisiz: {exc}")
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            "Cycles final render baglantilari yenilendi; F12 ile render alin.",
        )
        return {"FINISHED"}


def _input_sources(node):
    if node is None:
        return {}
    return {socket.name: [f"{link.from_node.name}.{link.from_socket.name}"
                          for link in socket.links]
            for socket in node.inputs if socket.is_linked}


def _upstream_image_nodes(effect):
    """Inspect the original image path without changing or bypassing it."""
    socket = effect.inputs.get("Image") if effect else None
    stack = [link.from_node for link in socket.links] if socket else []
    result, seen = [], set()
    while stack and len(result) < 128:
        node = stack.pop()
        if node.as_pointer() in seen:
            continue
        seen.add(node.as_pointer())
        entry = {"name": node.name, "type": node.bl_idname, "muted": node.mute}
        if node.bl_idname == "CompositorNodeRLayers":
            entry.update(scene=node.scene.name if node.scene else "current", layer=node.layer)
        if node.bl_idname == "CompositorNodeGroup" and node.node_tree:
            entry["group"] = node.node_tree.name
        for input_socket in node.inputs:
            if input_socket.name in {"Saturation", "Fac", "Factor"}:
                value = getattr(input_socket, "default_value", None)
                if isinstance(value, (float, int)):
                    entry[input_socket.name] = value
        result.append(entry)
        stack.extend(link.from_node for item in node.inputs for link in item.links)
    return result


def _diagnostic_snapshot(scene, context=None):
    """Read-only report: never repair the scene while trying to diagnose it."""
    tree = scene.compositing_node_group
    effect = tree.nodes.get(EFFECT_NODE_NAME) if tree else None
    pass_node = tree.nodes.get(PASS_NODE_NAME) if tree else None
    group_name = scene.get("cr_group_name", "")
    group = bpy.data.node_groups.get(group_name) if group_name else None
    graph = None
    if context is not None and not _render_in_progress():
        graph = context.evaluated_depsgraph_get()
    warnings, objects, grouped = [], [], {}
    for obj in _colored_objects(scene):
        index = _valid_selected_group(obj.get(SELECTED_GROUP_MARKER))
        actual = float(obj.cr_color_amount)
        evaluated = float(obj.evaluated_get(graph).cr_color_amount) if graph else actual
        grouped.setdefault(str(index), []).append(obj.name)
        slots = []
        for slot in obj.material_slots:
            material = slot.material
            aov = (material.node_tree.nodes.get(SELECTED_MATERIAL_NODES[2])
                   if material and material.node_tree else None)
            slots.append({"material": material.name if material else None,
                          "slot_link": slot.link,
                          "aov_name": aov.aov_name if aov else None,
                          "aov_value": float(aov.inputs["Value"].default_value) if aov else None})
        objects.append({"name": obj.name, "type": obj.type, "group": index,
                        "color_amount": actual, "evaluated_amount": evaluated,
                        "hide_render": obj.hide_render,
                        "pass_index": obj.pass_index,
                        "expected_pass_index": SELECTED_PASS_INDEX + index if index is not None else None,
                        "materials": slots})
        if evaluated <= 0.00001:
            warnings.append(f"{obj.name}: bu karede gercek renk degeri 0.")
        if index is None or obj.pass_index != SELECTED_PASS_INDEX + index:
            warnings.append(f"{obj.name}: Object Index atamasi uyusmuyor.")
    groups = {}
    for index, names in grouped.items():
        crypto = tree.nodes.get(f"{CRYPTOMATTE_NODE_PREFIX}{int(index):02d}") if tree and index != "None" else None
        values = [entry["evaluated_amount"] for entry in objects if entry["name"] in names]
        amount = group.nodes.get(f"CR_Selected_ID_Amount_{int(index):02d}") if group and index != "None" else None
        drivers = group.animation_data.drivers if group and group.animation_data else []
        path = amount.inputs[1].path_from_id("default_value") if amount else None
        driver = next((fc for fc in drivers if fc.data_path == path), None)
        groups[index] = {"members": names, "amount_min": min(values), "amount_max": max(values),
                         "index_amount": float(amount.inputs[1].default_value) if amount else None,
                         "driver_valid": driver.driver.is_valid if driver else False,
                         "driver_objects": [t.id.name if t.id else None for v in driver.driver.variables for t in v.targets] if driver else [],
                         "crypto_scene": crypto.scene.name if crypto and crypto.scene else None,
                         "crypto_layer": crypto.layer_name if crypto else None,
                         "crypto_matte_id": crypto.matte_id if crypto else None}
        if max(values) - min(values) > 0.001:
            warnings.append(f"Grup {index}: parcalarin renk animasyonu birbiriyle uyusmuyor.")
    layers = []
    for layer in scene.view_layers:
        excluded, stack = [], [layer.layer_collection]
        while stack:
            item = stack.pop()
            if item.exclude or item.collection.hide_render:
                excluded.append(item.name)
            stack.extend(item.children)
        layers.append({"name": layer.name, "render_enabled": layer.use,
                       "material_override": layer.material_override.name if layer.material_override else None,
                       "position": getattr(layer, "use_pass_position", None),
                       "object_index": layer.use_pass_object_index,
                       "cryptomatte_object": layer.use_pass_cryptomatte_object,
                       "aovs": [{"name": aov.name, "type": aov.type} for aov in layer.aovs],
                       "excluded_collections": excluded})
    if _scene_has_effect_data(scene) and _effect_needs_prepare(scene):
        warnings.append("Efektin render baglantilari hazir degil; render disinda yenileme gerekiyor.")
    upstream = _upstream_image_nodes(effect)
    if any(entry.get("Saturation", 1.0) == 0.0 for entry in upstream):
        warnings.append("Efekte gelen goruntu yolunda Saturation=0 dugumu var; ozgun renk kaybolmus olabilir.")
    controllers = _controllers(scene)
    volumes = [
        {
            "name": controller.name,
            "mode": _controller_mode(controller),
            "volume": _controller_volume(scene, controller, graph),
        }
        for controller in controllers
    ]
    active_camera = _active_camera_for_frame(scene)
    camera_modes = [
        {"name": obj.name, "mode": _camera_mode(obj)}
        for obj in scene.objects if obj.type == "CAMERA"
    ]
    return {"addon_version": ".".join(map(str, bl_info["version"])),
            "blender": bpy.app.version_string, "scene": scene.name,
            "engine": scene.render.engine, "frame": scene.frame_current,
            "compositing_enabled": scene.render.use_compositing,
            "lock_interface": scene.render.use_lock_interface,
            "render_in_progress": _render_in_progress(),
            "keyframe_entry_value_NOT_actual_object_color": scene.cr_animation_amount,
            "outside_saturation": scene.cr_outside_saturation,
            "cube_color_amount": scene.cr_cube_color_amount,
            "full_scene_color_amount": scene.cr_full_scene_color_amount,
            "yellow_filter": scene.cr_yellow_filter,
            "purple_filter": scene.cr_purple_filter,
            "controllers": volumes,
            "active_camera": active_camera.name if active_camera else None,
            "active_camera_mode": _camera_mode(active_camera),
            "camera_modes": camera_modes,
            "group_api": group.get("cr_api_version") if group else None,
            "effect_muted": effect.mute if effect else None,
            "mask_scene": pass_node.scene.name if pass_node and pass_node.scene else None,
            "mask_layer": pass_node.layer if pass_node else None,
            "pass_outputs": [s.name for s in pass_node.outputs] if pass_node else [],
            "effect_inputs": _input_sources(effect),
            "outputs": {n.name: _input_sources(n) for n in tree.nodes
                        if n.bl_idname == "NodeGroupOutput" and n.is_active_output} if tree else {},
            "upstream_image_nodes": upstream,
            "view_layers": layers, "groups": groups, "objects": objects, "warnings": warnings}


class CR_OT_copy_diagnostics(Operator):
    bl_idname = "cr.copy_diagnostics"
    bl_label = "Tani Raporunu Kopyala"
    bl_description = "Sahneyi degistirmeden gercek renk degerlerini ve render baglantilarini panoya kopyalar"

    def execute(self, context):
        report = _diagnostic_snapshot(context.scene, context)
        context.window_manager.clipboard = json.dumps(report, ensure_ascii=False, indent=2)
        self.report({"INFO"}, "Tani raporu kopyalandi; destek mesajina yapistirabilirsiniz.")
        return {"FINISHED"}


class CR_OT_render_preview_animation(Operator):
    bl_idname = "cr.render_preview_animation"
    bl_label = "Efektli Hizli Animasyon Preview Al"
    bl_description = (
        "Viewport Render Animation yerine gercek compositor sonucunu dusuk "
        "cozunurluk ve sample ile renderlar"
    )

    def execute(self, context):
        global _PREVIEW_RENDER_STATE, _PREVIEW_RESTORE_PENDING
        scene = context.scene
        if scene.render.engine != "CYCLES":
            self.report({"ERROR"}, "Bu hizli preview dugmesi Cycles icindir.")
            return {"CANCELLED"}
        if _render_in_progress():
            self.report({"ERROR"}, "Once devam eden renderi bitirin veya iptal edin.")
            return {"CANCELLED"}
        if not scene.render.filepath.strip():
            self.report({"ERROR"}, "Output Properties > Output yolunu once ayarlayin.")
            return {"CANCELLED"}

        # Finish restoring an earlier preview before capturing fresh settings.
        if _PREVIEW_RENDER_STATE is not None:
            _restore_preview_render_settings()
        if bpy.ops.cr.refresh_cycles_render() != {"FINISHED"}:
            return {"CANCELLED"}

        _PREVIEW_RENDER_STATE = {
            "scene": scene.name,
            "resolution_percentage": scene.render.resolution_percentage,
            "cycles_samples": scene.cycles.samples,
        }
        _PREVIEW_RESTORE_PENDING = False
        scene.render.resolution_percentage = scene.cr_preview_percentage
        scene.cycles.samples = scene.cr_preview_samples

        try:
            execution = "EXEC_DEFAULT" if bpy.app.background else "INVOKE_DEFAULT"
            result = bpy.ops.render.render(execution, animation=True)
        except Exception as exc:
            _restore_preview_render_settings()
            self.report({"ERROR"}, f"Preview render baslatilamadi: {exc}")
            return {"CANCELLED"}
        if result == {"CANCELLED"}:
            _restore_preview_render_settings()
            self.report({"ERROR"}, "Preview render baslatilamadi.")
            return {"CANCELLED"}
        if result == {"FINISHED"} and not _render_in_progress():
            _restore_preview_render_settings()

        self.report(
            {"INFO"},
            "Efektli preview render basladi. Bitince Render > View Animation ile izleyin.",
        )
        return {"FINISHED"}


class CR_OT_render_cycles_final(Operator):
    bl_idname = "cr.render_cycles_final"
    bl_label = "Cycles Final Render Al"
    bl_description = (
        "Efekt baglantilarini yeniler ve gercek F12 Cycles final renderini baslatir"
    )

    def execute(self, context):
        if context.scene.render.engine != "CYCLES":
            self.report({"ERROR"}, "Once Render Engine ayarini Cycles yapin.")
            return {"CANCELLED"}

        if bpy.ops.cr.refresh_cycles_render() != {"FINISHED"}:
            return {"CANCELLED"}

        bpy.ops.render.render("INVOKE_DEFAULT")
        return {"FINISHED"}


class CR_PT_panel(Panel):
    bl_label = "Renk Efekti"
    bl_idname = "CR_PT_color_reveal"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Renk Efekti"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        info = layout.box()
        info.label(text="Surum 4.12.2 - Blender 5.1.2")
        info.label(text="Renkli/renksiz kupler + kamera modlari")

        area_box = layout.box()
        area_box.label(text="1 - Kup Hacmi Modu")
        area_box.label(text="Bir veya daha fazla Cube sec")
        color_area = area_box.operator(
            "cr.setup_from_selected",
            text="Secili Kupleri Renkli Alan Yap",
            icon="MOD_MASK",
        )
        color_area.mode = "COLOR"
        gray_area = area_box.operator(
            "cr.setup_from_selected",
            text="Secili Kupleri Renksiz Alan Yap",
            icon="MOD_MASK",
        )
        gray_area.mode = "GRAY"

        controllers = _controllers(scene)
        area_box.label(text=f"Kontrol kupu: {len(controllers)} / {MAX_CONTROLLERS}")
        for controller in controllers[:4]:
            mode_label = "Renksiz" if _controller_mode(controller) == "GRAY" else "Renkli"
            area_box.label(text=f"{controller.name} ({mode_label})", icon="MESH_CUBE")
        if len(controllers) > 4:
            area_box.label(text=f"... ve {len(controllers) - 4} kup daha")
        controller_row = area_box.row(align=True)
        controller_row.operator(
            "cr.select_controller",
            text="Kupleri Goster",
            icon="HIDE_OFF",
        )
        controller_row.operator(
            "cr.hide_controller",
            text="Kupleri Gizle",
            icon="HIDE_ON",
        )
        remove_row = area_box.row(align=True)
        remove_selected = remove_row.operator(
            "cr.remove_controllers",
            text="Secili Kupu Cikar",
            icon="X",
        )
        remove_selected.all = False
        remove_all = remove_row.operator(
            "cr.remove_controllers",
            text="Tum Kupleri Temizle",
            icon="TRASH",
        )
        remove_all.all = True
        area_box.prop(scene, "cr_mask_margin")
        area_box.prop(scene, "cr_feather")
        area_box.prop(scene, "cr_cube_color_amount", text="Kup Etki Miktari", slider=True)
        cube_keys = area_box.row(align=True)
        cube_gray = cube_keys.operator(
            "cr.keyframe_area_amount",
            text="Kup Etkisini Kapat",
            icon="KEYFRAME",
        )
        cube_gray.amount = 0.0
        cube_gray.full_scene = False
        cube_color = cube_keys.operator(
            "cr.keyframe_area_amount",
            text="Kup Etkisini Ac",
            icon="KEYFRAME_HLT",
        )
        cube_color.amount = 1.0
        cube_color.full_scene = False
        area_box.label(text="Uzak keyframeler: yumusak renk gecisi")
        area_box.label(text="Dunyada sabit; kamerayi takip etmez")
        area_box.label(text="Cube kenari: Yumusak gecis")

        object_box = layout.box()
        object_box.label(text="2 - Karakter veya Esyayi Renkli Tut")
        object_box.label(text="Karakterde armature veya bir govde parcasi sec")
        object_box.operator(
            "cr.add_selected_color",
            text="Secilenleri Renkli Tut",
            icon="OUTLINER_OB_MESH",
        )
        object_actions = object_box.row(align=True)
        object_actions.operator(
            "cr.remove_selected_color",
            text="Secileni Cikar",
            icon="X",
        )
        object_actions.operator(
            "cr.clear_selected_color",
            text="Tumunu Temizle",
            icon="TRASH",
        )
        colored = _colored_objects(scene)
        object_box.label(text=f"Renkli kalacak parca: {len(colored)}")
        for obj in colored[:4]:
            object_box.label(text=obj.name, icon="OBJECT_DATA")
        if len(colored) > 4:
            object_box.label(text=f"... ve {len(colored) - 4} parca daha")
        object_box.label(text="Nesne maskesi: Tam yuzey ve keskin")

        animation_box = object_box.box()
        animation_box.label(text="3 - Nesne Rengini Animasyonla")
        active_targets = [obj for obj in _selected_color_targets(context)
                          if obj.get(SELECTED_MARKER, False)]
        if active_targets:
            values = [obj.cr_color_amount for obj in active_targets]
            amount_text = f"{min(values):.2f}" if max(values) - min(values) < 0.001 else f"{min(values):.2f} - {max(values):.2f}"
            animation_box.label(text=f"Bu karede gercek renk: {amount_text}")
        animation_box.prop(scene, "cr_animation_amount", slider=True)
        key_button = animation_box.operator(
            "cr.keyframe_selected_amount",
            text="Bu Kareye Renk Keyframe'i Ekle",
            icon="KEY_HLT",
        )
        key_button.use_panel_amount = True
        quick_keys = animation_box.row(align=True)
        gray_key = quick_keys.operator(
            "cr.keyframe_selected_amount",
            text="Renksiz (0)",
            icon="KEYFRAME",
        )
        gray_key.amount = 0.0
        color_key = quick_keys.operator(
            "cr.keyframe_selected_amount",
            text="Renkli (1)",
            icon="KEYFRAME_HLT",
        )
        color_key.amount = 1.0
        animation_box.label(text="Uzak keyframeler: yumusak renk gecisi")
        animation_box.label(text="Nesne dis kenari daima keskin")

        motion_box = layout.box()
        motion_box.label(text="4 - Motion Blur Animasyonu")
        current_shutter = scene.render.motion_blur_shutter
        current_state = "Acik" if scene.render.use_motion_blur and current_shutter > 0.0001 else "Kapali"
        motion_box.label(text=f"Bu karede: {current_state} (Shutter {current_shutter:.2f})")
        motion_box.prop(scene, "cr_motion_blur_shutter", slider=True)
        motion_keys = motion_box.row(align=True)
        off_key = motion_keys.operator(
            "cr.keyframe_motion_blur",
            text="Bu Karede Kapat",
            icon="KEYFRAME",
        )
        off_key.enable = False
        on_key = motion_keys.operator(
            "cr.keyframe_motion_blur",
            text="Bu Karede Ac",
            icon="KEYFRAME_HLT",
        )
        on_key.enable = True
        motion_box.label(text="Ac/Kapat gecisi tam keyframe karesinde olur")

        camera_box = layout.box()
        camera_box.label(text="5 - Kamera Renk Modu")
        selected = context.active_object
        selected_camera = (
            selected if selected is not None and selected.type == "CAMERA"
            else scene.camera
        )
        if selected_camera is None:
            camera_box.label(text="Bir kamera secin", icon="ERROR")
        else:
            camera_labels = {
                "NORMAL": "Normal Efekt",
                "COLOR": "Tam Renkli",
                "GRAY": "Taban Renksiz",
            }
            camera_box.label(text=f"Kamera: {selected_camera.name}", icon="CAMERA_DATA")
            camera_box.label(text=f"Mod: {camera_labels[_camera_mode(selected_camera)]}")
        camera_modes = camera_box.row(align=True)
        normal_camera = camera_modes.operator(
            "cr.set_camera_mode", text="Normal", icon="MOD_MASK"
        )
        normal_camera.mode = "NORMAL"
        color_camera = camera_modes.operator(
            "cr.set_camera_mode", text="Renkli", icon="KEYFRAME_HLT"
        )
        color_camera.mode = "COLOR"
        gray_camera = camera_modes.operator(
            "cr.set_camera_mode", text="Renksiz", icon="KEYFRAME"
        )
        gray_camera.mode = "GRAY"
        camera_box.label(text="Mod her kamera objesine ayri kaydedilir")
        camera_box.label(text="Kamera kesmesinde ayni karede degisir")
        camera_box.label(text="Renkli tutulan nesneler Renksiz kamerada korunur")

        preview = layout.box()
        if _preview_space_is_ready(context.space_data, scene):
            preview.label(text="Canli onizleme acik", icon="CHECKMARK")
        else:
            warning = preview.row()
            warning.alert = True
            warning.label(text="Kamera/Rendered onizleme kapali", icon="ERROR")
        preview.operator(
            "cr.enable_live_preview",
            text="Canli Onizlemeyi Ac",
            icon="RESTRICT_RENDER_OFF",
        )
        preview.operator(
            "cr.refresh_cycles_render",
            text="Cycles Renderini Yenile",
            icon="FILE_REFRESH",
        )
        preview.operator(
            "cr.render_cycles_final",
            text="Cycles Final Render Al (F12)",
            icon="RENDER_STILL",
        )
        preview.separator()
        preview.label(text="Animasyon Preview (efektli)")
        preview.prop(scene, "cr_preview_percentage")
        preview.prop(scene, "cr_preview_samples")
        preview.operator(
            "cr.render_preview_animation",
            text="Efektli Hizli Animasyon Preview Al",
            icon="RENDER_ANIMATION",
        )
        preview.label(text="Viewport Render Animation efekti kaydetmez")
        preview.operator("cr.copy_diagnostics", icon="COPYDOWN")
        if _cycles_object_preview_required(scene):
            preview.label(text="Nesne onizlemesi: Material Preview")
            preview.label(text="Final render motoru degismez")
            if getattr(context.space_data.shading, "type", "") == "RENDERED":
                cycles_warning = preview.column(align=True)
                cycles_warning.alert = True
                cycles_warning.label(text="Cycles Rendered viewport maskeyi gostermez")
                cycles_warning.label(text="Canli Onizlemeyi Ac dugmesine basin")

        common = layout.box()
        common.label(text="Ortak Ayar")
        common.prop(scene, "cr_outside_saturation")
        common.separator()
        common.prop(scene, "cr_full_scene_color_amount", slider=True)
        full_keys = common.row(align=True)
        full_off = full_keys.operator(
            "cr.keyframe_area_amount",
            text="Tam Rengi Kapat",
            icon="KEYFRAME",
        )
        full_off.amount = 0.0
        full_off.full_scene = True
        full_on = full_keys.operator(
            "cr.keyframe_area_amount",
            text="Tumunu Renkli Yap",
            icon="KEYFRAME_HLT",
        )
        full_on.amount = 1.0
        full_on.full_scene = True
        common.label(text="1: gokyuzu ve kamera kenarlari da renkli")
        common.separator()
        common.prop(scene, "cr_yellow_filter", slider=True)
        common.prop(scene, "cr_purple_filter", slider=True)

        layout.separator()
        layout.label(text="Kup ve secilen nesneler her zaman birlikte calisir")
        layout.label(text="Kup alani dunya koordinatinda sabittir.")


classes = (
    CR_OT_setup_from_selected,
    CR_OT_set_camera_mode,
    CR_OT_enable_live_preview,
    CR_OT_select_controller,
    CR_OT_hide_controller,
    CR_OT_remove_controllers,
    CR_OT_add_selected_color,
    CR_OT_keyframe_selected_amount,
    CR_OT_keyframe_area_amount,
    CR_OT_keyframe_motion_blur,
    CR_OT_remove_selected_color,
    CR_OT_clear_selected_color,
    CR_OT_refresh_cycles_render,
    CR_OT_copy_diagnostics,
    CR_OT_render_preview_animation,
    CR_OT_render_cycles_final,
    CR_PT_panel,
)


def register():
    global _REGISTERED, _RENDERING, _FRAME_DIRTY
    _REGISTERED = True
    _RENDERING = False
    _FRAME_DIRTY = True
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.cr_controller = PointerProperty(
        name="Efekt Kontrol Objesi",
        description="Dunya hacmi icindeki yuzeyleri renkli veya renksiz yapan Cube/mesh obje",
        type=bpy.types.Object,
    )
    bpy.types.Scene.cr_mask_margin = FloatProperty(
        name="Alan Genisligi",
        description="Renkli alanin kontrol objesine gore genislik carpani",
        default=1.0,
        min=0.05,
        max=5.0,
        update=_settings_update,
    )
    bpy.types.Scene.cr_feather = IntProperty(
        name="Gecis Yumusakligi",
        description="Kup sinirindaki yumusak gecis; 0 keskin, 1000 kup yari boyunun tamami",
        default=140,
        min=0,
        max=1000,
        update=_settings_update,
    )
    bpy.types.Scene.cr_outside_saturation = FloatProperty(
        name="Dis Alan Rengi",
        description="0 tam siyah-beyaz, 1 tamamen renkli",
        default=0.0,
        min=0.0,
        max=1.0,
        update=_settings_update,
    )
    bpy.types.Scene.cr_yellow_filter = FloatProperty(
        name="Sarilik Filtresi",
        description="0 kapali, 1 guclu sari sicaklik filtresi",
        default=0.0,
        min=0.0,
        max=1.0,
        update=_settings_update,
    )
    bpy.types.Scene.cr_purple_filter = FloatProperty(
        name="Morluk Filtresi",
        description="0 kapali, 1 guclu mor/magenta renk filtresi",
        default=0.0,
        min=0.0,
        max=1.0,
        update=_settings_update,
    )
    bpy.types.Scene.cr_cube_color_amount = FloatProperty(
        name="Kup Etki Miktari",
        description="0 tum kup hacimleri kapali, 1 renkli ve renksiz kup hacimleri tam etkili",
        default=1.0,
        min=0.0,
        max=1.0,
        options={"ANIMATABLE"},
        update=_settings_update,
    )
    bpy.types.Scene.cr_full_scene_color_amount = FloatProperty(
        name="Tum Sahne Rengi",
        description="0 normal kup/nesne maskesi, 1 kamera kenarlari ve gokyuzu dahil tum goruntu renkli",
        default=0.0,
        min=0.0,
        max=1.0,
        options={"ANIMATABLE"},
        update=_settings_update,
    )
    bpy.types.Scene.cr_animation_amount = FloatProperty(
        name="Yeni Keyframe Degeri",
        description="Eklenecek anahtar karenin degeri; nesnenin mevcut renk degeri degildir",
        default=1.0,
        min=0.0,
        max=1.0,
    )
    bpy.types.Scene.cr_motion_blur_shutter = FloatProperty(
        name="Acikken Shutter",
        description="Motion Blur acik keyframe'inde kullanilacak shutter miktari",
        default=0.5,
        min=0.01,
        max=2.0,
    )
    bpy.types.Scene.cr_preview_percentage = IntProperty(
        name="Preview Cozunurlugu (%)",
        description="Efektli animasyon preview renderinda kullanilacak cozunurluk yuzdesi",
        default=25,
        min=5,
        max=100,
    )
    bpy.types.Scene.cr_preview_samples = IntProperty(
        name="Preview Samples",
        description="Efektli animasyon preview renderinda kullanilacak Cycles sample sayisi",
        default=8,
        min=1,
        max=4096,
    )
    bpy.types.Object.cr_color_amount = FloatProperty(
        name="Renk Miktari",
        description="Bu nesnenin animasyonlu renk miktari: 0 renksiz, 1 renkli",
        default=1.0,
        min=0.0,
        max=1.0,
        options={"ANIMATABLE"},
    )

    for handler_list, callback in _handler_bindings():
        if callback not in handler_list:
            handler_list.append(callback)

    # Preferences icindeki kurulum aninda bpy.data _RestrictData olabilir.
    # Sahne taramasini kayit tamamlandiktan sonraya birak.
    if not bpy.app.timers.is_registered(_cr_initialize_existing_scenes):
        bpy.app.timers.register(
            _cr_initialize_existing_scenes, first_interval=0.1, persistent=True,
        )


def _handler_bindings():
    return (
        (bpy.app.handlers.frame_change_post, _cr_frame_change),
        (bpy.app.handlers.depsgraph_update_post, _cr_depsgraph_changed),
        (bpy.app.handlers.render_init, _cr_render_started),
        (bpy.app.handlers.render_pre, _cr_render_prepare),
        (bpy.app.handlers.render_complete, _cr_render_finished),
        (bpy.app.handlers.render_cancel, _cr_render_finished),
        (bpy.app.handlers.load_post, _cr_load_post),
    )


def unregister():
    global _REGISTERED, _RENDERING, _PREVIEW_RENDER_STATE, _PREVIEW_RESTORE_PENDING
    if not _render_in_progress():
        _restore_preview_render_settings()
    else:
        _PREVIEW_RENDER_STATE = None
        _PREVIEW_RESTORE_PENDING = False
    _REGISTERED = False
    _RENDERING = False
    if bpy.app.timers.is_registered(_cr_initialize_existing_scenes):
        bpy.app.timers.unregister(_cr_initialize_existing_scenes)

    for handler_list, callback in _handler_bindings():
        if callback in handler_list:
            handler_list.remove(callback)

    for prop_name in (
        "cr_preview_samples",
        "cr_preview_percentage",
        "cr_motion_blur_shutter",
        "cr_animation_amount",
        "cr_full_scene_color_amount",
        "cr_cube_color_amount",
        "cr_purple_filter",
        "cr_yellow_filter",
        "cr_outside_saturation",
        "cr_effect_mode",
        "cr_feather",
        "cr_mask_margin",
        "cr_controller",
    ):
        if hasattr(bpy.types.Scene, prop_name):
            delattr(bpy.types.Scene, prop_name)

    if hasattr(bpy.types.Object, "cr_color_amount"):
        del bpy.types.Object.cr_color_amount

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
