# barismsi Color Reveal - Blender 5.1.2

Bu surum Blender **5.1.2** icin hazirlanmistir.
Eklenti panelinde dogru kurulum icin **Surum 4.12.2** yazisini gorursunuz.

## 4.12.2 duzeltmesi

- **Renksiz Kamera** artik renkli Cube alanlarini kapatmaz; yalnizca kameranin temel goruntusunu siyah-beyaz yapar.
- Renkli Cube icindeki gorunur yuzeyler, Renksiz Kamera kullanilirken de renkli gorunur.
- **Secilenleri Renkli Tut** listesindeki karakter ve esyalar da Renksiz Kamera kullanilirken renkli kalir.
- Renksiz kamerada **Tum Sahne Rengi** devre disi kalir; renkli Cube ve secili nesne maskeleri ise calismaya devam eder.

## 4.12.1 duzeltmesi

- **Renksiz Kamera** artik sahneyi siyah-beyaz yaparken **Secilenleri Renkli Tut** listesindeki karakter ve esyalari griye cevirmez.
- Secilen karakter/esya maskesi en yuksek oncelige alindi; Renksiz Kamera veya Renksiz Cube ile cakissa bile kendi renk miktarina gore renkli kalir.
- Nesnenin animasyonlu renk miktari `0` ise gri, `1` ise renkli gorunur; kenari yine keskindir.

## 4.12.0 yeniligi

- Her kontrol Cube'u ayri olarak **Renkli Alan** veya **Renksiz Alan** yapilabilir.
- Renksiz Cube, renkli sahnenin icinden yumusak sinirli siyah-beyaz bir bolge cikarir.
- Her kamera ayri olarak **Normal**, **Renkli** veya **Renksiz** moda atanabilir.
- Timeline Camera Marker ile aktif kamera degistiginde yeni kameranin modu ayni karede uygulanir.
- Renksiz kamera temel goruntuyu gri yapar; renkli Cube ve secili nesneler renk gostermeye devam eder. Renksiz Cube ise renkli kamera veya renkli sahne icinde bile kendi hacmini gri tutar.

## 4.11.0 yeniligi

- Ayni sahnede birden fazla kontrol Cube'u kullanilabilir.
- Iki veya daha fazla Cube'u birlikte secip **Secili Kupleri Renkli Alan Yap** dugmesine bir kez basabilirsiniz.
- Her Cube dunya icinde ayri bir renk hacmi olusturur; tum hacimler birlikte calisir.
- Sonradan yeni Cube eklemek onceki Cube'lari kapatmaz.
- **Kupleri Goster**, **Kupleri Gizle**, **Secili Kupu Cikar** ve **Tum Kupleri Temizle** kontrolleri eklendi.
- En fazla `32` ayri kontrol Cube'u kullanilabilir.

## 4.10.0 yeniligi

- **Kup Renk Miktari** ile Cube hacmi `0` (renksiz) ve `1` (renkli) arasinda ayarlanabilir.
- **Kupu Renksiz Yap** ve **Kupu Renkli Yap** dugmeleri mevcut kareye keyframe ekler.
- Iki uzak Cube keyframe'i arasinda zaman icinde yumusak renk gecisi olusur.
- **Tum Sahne Rengi** ayari `1` yapildiginda Cube boyutundan bagimsiz olarak gokyuzu ve kamera kenarlari dahil tum final goruntu renkli olur.
- **Tam Rengi Kapat** ve **Tumunu Renkli Yap** dugmeleriyle tam sahne rengi de animasyonlanabilir.

## 4.9.0 yeniligi

- Cube maskesi artik kameraya projekte edilen 2B bir dikdortgen degildir.
- Cube, sahnede dunya koordinatlarina bagli sabit bir 3B renk hacmidir.
- Kamera donse, hareket etse veya baska yone baksa bile renk alani kamerayla birlikte kaymaz.
- Yalnizca Cube'un fiziksel hacmi icinde bulunan gorunur yuzeyler renkli olur.
- Cube'un konumu, donusu ve X/Y/Z olcegi hesaba katilir.
- Yumusak gecis kamera pikseline degil, Cube'un dunya uzayindaki sinirina uygulanir.

## 4.8.3 yeniligi

- Motion Blur istenen karelerde acilip kapatilabilir.
- **Bu Karede Kapat** shutter degerini `0` yapar.
- **Bu Karede Ac** ayarlanan **Acikken Shutter** degerini keyframe olarak ekler.
- Keyframeler `Constant` oldugu icin ac/kapat gecisi tam secilen karede gerceklesir.

## 4.8.2 duzeltmesi

- Ayri renk animasyonu kullanabilen karakter/esya grubu siniri `16`dan `64`e cikarildi.
- Bir Minecraft karakterinin tum govde parcalari tek grup sayilir.
- Cryptomatte dugumleri 64 grubun tamami icin degil, yalniz kullanilan gruplar icin olusturulur.
- **Morluk Filtresi** ve efektli hizli animasyon preview dugmesi eklendi.

## 4.8.1 duzeltmesi

Onceki surum render callback'i icinde nesnelerin `pass_index` degerlerini yeniden
yaziyordu. Gonderilen Windows cokme kaydi `_sync_selected_index_masks` satirini
gosteriyor. Artik render callback'leri nesne kimliklerini, materyalleri, driver'lari
ve dugum baglantilarini yeniden kurmaz. Kurulum ve yenileme ana is parcaciginda,
render baslamadan yapilir; render sirasinda bu islemler engellenir.

Kurulum **Render > Lock Interface** ayarini acar. Hareketli kup icin renderda
yalniz mevcut compositor degerleri guncellenir. Render devam ederken arayuzun
kilitlenmesi beklenen davranistir. Bu ayari render oncesinde kapatmayin.

Bu guncelleme kayittaki cokmeye yol acan kod yolunu kaldirir. Kullanicinin
Minecraft `.blend` sahnesi olmadan o sahnenin renksiz cikma nedeni dogrulanamaz.
Testler Blender 5.1.2 Linux / CPU Cycles uzerinde sentetik sahnelerle yapilmistir;
Windows arayuzu, kullanicinin rig'i ve diger eklentileri ayni ortamda denenmemistir.

## Ne yapar?

- Bir veya daha fazla Cube'un dunya icindeki 3B hacimlerini renkli veya renksiz alan olarak kullanir.
- Istediginiz karakteri veya esyayi secerek yalniz onu renkli tutar.
- Cube alani ve secilen nesneler her zaman birlikte calisir; birini eklemek digerini kapatmaz.
- Bir Armature veya ona bagli tek bir govde parcasi secildiginde karakterin tum mesh parcalarini otomatik bulur.
- Birden fazla karakter veya esya renkli listesine eklenebilir.
- Cube alaninda renkli ve siyah-beyaz bolgeler arasinda yumusak gecis uygular.
- Secilen karakter veya esyada yalnizca gercek nesne yuzeyi renkli kalir; etrafinda dikdortgen, elips veya yumusak renk alani olusmaz.
- Secilen karakter veya esyanin kenari keskindir; bu maskeye yumusak gecis uygulanmaz.
- Secilen karakter veya esyanin renk miktari keyframe ile `0` (renksiz) ve `1` (renkli) arasinda animasyonlanabilir.
- Birbirinden uzak iki renk keyframe'i arasinda zaman icinde yumusak renk gecisi olusur; nesnenin dis kenari yine keskin kalir.
- **Sarilik Filtresi** ile son goruntuye istediginiz miktarda sicak sari ton eklenebilir.
- **Morluk Filtresi** ile son goruntuye istediginiz miktarda mor/magenta ton eklenebilir.
- Kontrol Cube'u viewport ve renderda otomatik gizlenir.
- Elle materyal, texture, UV veya maske hazirlamaniz gerekmez.

## Kurulum

1. Blender'da **Edit > Preferences > Add-ons** bolumunu acin.
2. Sag ustteki menuden **Install from Disk** secin.
3. `barismsi_color_reveal_addon.zip` dosyasini secin.
4. **barismsi Color Reveal** eklentisini etkinlestirin.

Once `.blend` dosyanizin bir yedegini alin. Renderi durdurun. Eski surum kuruluysa
kaldirin, **Blender'i tamamen kapatip yeniden baslatin** ve yeni ZIP'i yukleyin.
Bu adim eski surumun bellekten calisan callback'lerinin kalmamasi icindir.
Mevcut renk listesini veya animasyon keyframe'lerini temizlemeyin.
Sahneyi actiktan sonra, render disindayken bir kez **Cycles Renderini Yenile**'ye basin.

## Kullanim - Kup Alani

1. Sahnede aktif bir kamera bulunsun.
2. `Shift + A > Mesh > Cube` ile bir veya daha fazla kup ekleyin.
3. Kupleri renkli kalacak nesne ve yuzeyleri fiziksel olarak kapsayacak yerlere yerlestirin.
4. Kullanmak istediginiz tum kupleri birlikte secip `N > Renk Efekti` panelini acin.
5. Bolgeyi renkli yapmak icin **Secili Kupleri Renkli Alan Yap**, siyah-beyaz yapmak icin **Secili Kupleri Renksiz Alan Yap** dugmesine basin.
6. Eklenti kameraya, Rendered moda ve Viewport Compositor'a otomatik gecer.
7. Kupler otomatik gizlenir. Duzenlemek icin **Kupleri Goster** dugmesine basin.
8. `G` ile tasiyin; `S`, `S X`, `S Y` ve `S Z` ile hacmi boyutlandirin. `R` ile dondurebilirsiniz.
9. Bitirince **Kupleri Gizle** dugmesine basin.

Sonradan yeni bir Cube eklemek icin yalniz yeni Cube'u secip istediginiz alan
dugmesine basabilirsiniz. Var olan hacimler listede kalir. Var olan bir Cube'un
modunu degistirmek icin **Kupleri Goster**, Cube'u secin ve diger alan dugmesine
basin. Bir hacmi kaldirmak icin once
**Kupleri Goster**'e basin, kaldirilacak Cube'u tek basina secin ve **Secili Kupu
Cikar**'i kullanin.

Cube artik kamerayla sahne arasinda duran bir pencere degildir. Bir yuzey ekranda
Cube'un arkasinda gorunse bile dunya konumunda Cube hacminin disindaysa renklenmez.
Kamera acisini degistirdiginizde ayni dunya bolgesi renkli kalir; yalniz ekrandaki
gorunusu kameranin normal perspektifine gore yer degistirir.

## Cube rengini animasyonlama

1. Cube veya Cube'lari once renkli ya da renksiz alan dugmesiyle kurun.
2. Etkinin kapanacagi karede **Kup Etkisini Kapat** dugmesine basin.
3. Etkinin acilacagi karede **Kup Etkisini Ac** dugmesine basin.
4. Arada cok kare varsa tum Cube etkilerinin miktari zaman icinde yumusak bicimde degisir.

Paneldeki **Kup Etki Miktari** kaydiricisini `0` ile `1` arasinda elle de
ayarlayabilirsiniz. `0`, renkli ve renksiz Cube maskelerini kapatir; renk listesine eklenen nesneleri
ve **Tum Sahne Rengi** ayarini kapatmaz.

## Kamera basina renk modu

1. Outliner veya 3D Viewport'ta ayarlamak istediginiz kamera nesnesini secin.
2. `N > Renk Efekti > Kamera Renk Modu` bolumune gidin.
3. **Normal**, **Renkli** veya **Renksiz** dugmesine basin.
4. Diger kameralari da secip kendi modlarini ayri ayri kaydedin.

**Normal** mod mevcut Cube ve secili nesne maskelerini kullanir. **Renkli** mod
kameranin tum goruntusunu renkli yapar; ancak bir Renksiz Cube varsa o hacim yine
gri kalir. **Renksiz** mod kamera tabanini siyah-beyaz yapar; Renkli Cube alanlari
ve renkli tutulan karakter/esyalar renkli gorunmeye devam eder.
Timeline'daki kamera kesmeleri icin ek keyframe gerekmez; mod kamera objesinde
saklanir ve aktif kamerayla birlikte degisir.

## Kamera kenarlari dahil tum sahneyi renkli yapma

Cube'u kameranin tamamini kaplayacak kadar buyutmek yerine **Ortak Ayar > Tum
Sahne Rengi** degerini `1` yapin. Bu ayar dunya konumu gecidi bulunmayan gokyuzu
ve kamera cercevesinin kenarlari dahil final goruntunun tamamini renkli yapar.

- **Tam Rengi Kapat:** Bu karede degeri `0` yapar ve normal Cube/nesne maskesine doner.
- **Tumunu Renkli Yap:** Bu karede degeri `1` yapar.

Bu iki dugme keyframe ekler. Aralarinda cok kare varsa butun sahne yavas yavas
renklenir veya renksizlesir.

## Kullanim - Secilen Karakter veya Esya Renkli

1. Renkli kalmasini istediginiz karakteri veya esyayi secin.
2. Karakter bir rig ise Armature'u veya Armature'a bagli govde parcalarindan birini secmeniz yeterlidir.
3. `N > Renk Efekti` panelinde **Secilenleri Renkli Tut** dugmesine basin.
4. Cube alani varsa etkin kalmaya devam eder; iki efekt otomatik birlestirilir.
5. Secilen karakter veya esya renkli, sahnenin geri kalani siyah-beyaz olur.
6. Baska nesneler eklemek icin onlari secip ayni dugmeye tekrar basin.
7. Bir nesneyi cikarmak icin **Secileni Cikar**, hepsini kaldirmak icin **Tumunu Temizle** dugmesini kullanin.

Bu sistem mevcut texture ve gorunumu degistirmez. Eklenti secilen objeye ozel bir materyal kopyasi atar ve yalnizca gercek yuzey piksellerinden keskin AOV maskesi uretir. Nesneyi listeden cikardiginizda asil materyali geri yukler.

Sahnenin final render motoru Cycles ise eklenti Blender 5.1.2'nin isim tabanli **Cryptomatte Object** gecisini etkinlestirir. AOV ve Object Index yollari da korunur. Paneldeki **Cycles Final Render Al (F12)** dugmesi once baglantilari yeniler, sonra final renderini baslatir. Render motorunu sonradan degistirirseniz render baslamadan **Cycles Renderini Yenile**'yi kullanin; render callback'i eksik baglantilari onarmaya calismaz.

Blender 5.1.2 canli Viewport Compositor, Cycles motorunda Shader AOV/render pass sonucunu gostermez. Bu nedenle 3D Viewport'taki **Cycles Rendered** gorunumu secilen nesneyi renkli gosteremez. Eklenti canli nesne onizlemesini EEVEE tabanli **Material Preview** modunda gosterir; final render motorunuz yine Cycles olarak kalir.

## Efektli animasyon preview

Blender'in `View > Render Viewport Animation` komutu 3D Viewport goruntusunu
kaydeder ve bu eklentinin final compositor maskelerini animasyon cikisina katmaz.
Bu nedenle ekranda efekt gorunse bile o komutun cikisi tamamen renkli olabilir.

Panelde **Preview Cozunurlugu (%)** ve **Preview Samples** degerlerini ayarlayip
**Efektli Hizli Animasyon Preview Al** dugmesine basin. Bu dugme normal Cycles
animasyon renderini dusuk ayarlarla calistirdigi icin Cube alani, secilen nesne
maskeleri, sari/mor filtreler ve siyah-beyaz cevre ciktiya dahil edilir. Render bittiginde
cozunurluk yuzdesi ile Cycles sample sayisi onceki degerlerine geri doner.
Olusan kareler mevcut `Output Properties > Output` yoluna yazilir. Izlemek icin
`Render > View Animation` komutunu kullanin.

## Kullanim - Nesne Rengini Animasyonla

1. Karakteri veya esyayi once **Secilenleri Renkli Tut** ile renk listesine ekleyin.
2. Nesneyi veya karakterin Armature'unu secili tutun.
3. Renksiz olmasini istediginiz kareye gidip **Renksiz (0)** dugmesine basin.
4. Renkli olmasini istediginiz baska bir kareye gidip **Renkli (1)** dugmesine basin.
5. Iki kare arasinda renk miktari Bezier keyframe'lerle yumusak bicimde degisir.
6. Isterseniz **Yeni Keyframe Degeri** alanina `0` ile `1` arasinda ara bir deger yazip **Bu Kareye Renk Keyframe'i Ekle** dugmesini kullanin.

**Bu karede gercek renk** yazisi secilen nesnenin mevcut animasyon degerini
gosterir. **Yeni Keyframe Degeri** sadece eklenecek keyframe icin giris alanidir;
tek basina mevcut nesne rengini gostermez veya degistirmez. Cube alaniyla ortusen
nesneler, kendi renk degerleri 0 olsa da ortak alan maskesi nedeniyle renklenebilir.

Bu gecis yalnizca nesnenin doygunlugunu zaman icinde degistirir. Nesnenin disindaki alan renklenmez ve nesnenin siluet kenari yumusamaz.

## Motion Blur'u karelerde acip kapatma

Blender 5.1.2'de ana **Use Motion Blur** secenegi animasyonlanamaz. Eklenti bu
secenegi acik tutar ve animasyonlanabilen `Motion Blur Shutter` degerini kullanir.
Shutter `0` oldugunda blur kapali, sifirdan buyuk oldugunda aciktir.

1. `N > Renk Efekti > Motion Blur Animasyonu` bolumunu acin.
2. Blur acikken kullanilacak **Acikken Shutter** degerini belirleyin. `0.50` normal bir baslangictir.
3. Blur'un kapanacagi karede **Bu Karede Kapat** dugmesine basin.
4. Acilacagi karede **Bu Karede Ac** dugmesine basin.

Ornek: 100. karede kapatip 150. karede acarsaniz 100-149 arasinda Motion Blur
kapali, 150. kareden itibaren acik olur. Panelde **Bu karede: Acik/Kapali** durumu
ve o karedeki gercek shutter degeri gorunur.

## Birlesik Efekt

Dunya hacmini belirleyen Cube ve renkli listesine eklenen karakter/esyalar ayni anda etkindir. Cube dugmesine veya nesne dugmesine basmak diger efekti kapatmaz.

## Ayarlar

- **Alan Genisligi:** Renkli alanin kontrol kupune gore genislik carpanidir.
- **Gecis Yumusakligi:** Dunya uzayindaki Cube sinirinin yumusakligidir. `0` keskin; `140`, Cube yari boyutunun yaklasik `%14`u kadar yumusak gecistir.
- **Kup Etki Miktari:** `0` tum Cube alanlarini kapatir, `1` renkli/renksiz Cube alanlarini tam etkinlestirir ve animasyonlanabilir.
- **Tum Sahne Rengi:** `1` iken gokyuzu ve kamera kenarlari dahil tum final goruntu renklidir; `0` normal Cube/nesne maskesidir.
- **Dis Alan Rengi:** `0` tam siyah-beyaz, `1` tamamen renklidir.
- **Sarilik Filtresi:** `0` kapali, `1` guclu sari/sicak filtredir.
- **Morluk Filtresi:** `0` kapali, `1` guclu mor/magenta filtredir.

## Cycles sonucunu teshis etme

Final render hala renksizse **Tani Raporunu Kopyala**'ya basin ve raporu destek
mesajina yapistirin. Bu dugme sahneyi degistirmez; mevcut karedeki gercek nesne
renklerini, grup driver'larini, View Layer / Object Index / Cryptomatte
baglantilarini ve efekte gelen goruntu yolunu raporlar. Rapor nesne ve materyal
adlari icerir; dosya yollarini veya texture dosyalarini kopyalamaz.

Efekte gelen goruntu onceki bir compositor dugumunde zaten siyah-beyaza
cevrilmisse bir maske kaybolan rengi geri getiremez. Kesin inceleme icin sorunlu
karakteri, kamerayi, isiklari ve compositor'u iceren bir `.blend` kopyasi gerekir.
Paylasmadan once `File > External Data > Pack Resources` ile texture'lari paketleyin
ve `Save As` ile ayri bir kopya kaydedin; asil projenizin uzerine yazmayin.

## Onemli

Efekt final goruntuye compositor'da uygulanir; ancak Cube maskesi kameraya degil
dunya koordinatlarina baglidir. Canli onizleme icin aktif **Camera** gorunumu gerekir.
Cycles'ta nesne onizlemesi **Material Preview** kullanir;
bu onizleme ile F12 Cycles final renderi ayni islem degildir.
**Canli Onizlemeyi Ac** dugmesi gerekli onizleme ayarlarini yapar.

Rendered gorunum gercek sahne isiklarini kullanir. Goruntu cok karanliksa Sun/Area Light veya World aydinlatmasini kontrol edin.
